import{aq as l,X as t,q as o,a4 as d,o as s,n as e,al as y,ar as p,as as h,a0 as u}from"./index.html-a1016547.js";import{aV as n}from"./index-23cb1aae.js";const v=()=>{const[a,r]=n.useState(),c=n.useCallback(l,[]);return n.useEffect(()=>{c().then(r)},[]),a},k=t.div`
     margin:20px 10px;
`,x=t.h3`
    font-size:24px;
    padding: 15px 0;
    text-align:center;
    margin-top: 8px;
`,m=t(o)`
    --border-inner: 0;
    --border-bottom: 0;
    --border-top: 0;
`,i=t(o.Item)`
    font-size:12px;
    color:#999;
`,b=t(o.Item)`
    user-select: none;
    cursor:pointer;
`,K=()=>{const a=d(),r=v();return s("div",{children:[e(y,{back:"back",onBack:()=>{a(-1)}}),s(k,{children:[e(x,{children:"Export private key"}),s(m,{mode:"card",children:[e(i,{children:"This is your private key (click to copy)"}),e(p,{onCopy:()=>h.show({content:"copyed"}),text:r||"",children:e(b,{style:{wordBreak:"break-all"},arrow:!1,children:r})}),e(i,{children:"Warning: Never disclose this key. Anyone with your private keys can steal any assets held in your account."}),e(o.Item,{children:e(u,{block:!0,onClick:()=>{a("/account/tokens")},children:"Done"})})]})]})]})};export{K as default};
//# sourceMappingURL=index-6b3d04a2.js.map
