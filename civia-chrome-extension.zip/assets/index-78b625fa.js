import{X as t,a5 as p,a4 as g,bg as m,n as a,W as r,o as c,j as s,aH as u,ad as y,aC as h,_ as f}from"./index.html-a1016547.js";import"./index-23cb1aae.js";import{a as b}from"./useCollections-cb9cca63.js";import"./aspect.service-1342d8b4.js";import"./useNfts-8eacf436.js";const x=t.div`
    min-height:320px;
    margin: 10px 0;
`,k=t.h3`
    font-size:24px;
    padding: 15px 0;
    text-align:center;
    margin-top: 8px;
`,v=t.div`
    svg{
        path{
            fill: #4A4A4A!important;
        }
    }
`,B=t(y)`
    border:1px solid var(--adm-color-box);
    &:hover{
        border-color: var(--adm-color-border);
        cursor: pointer;
    }
`,C=t(h)`
    background-size: contain;
    background-position: center;
    background-repeat: no-repeat;
    background-color: #fefefe;
`,_=t(f)`
    padding: 0 32px;
`,H=()=>{const d=p(),e=g(),l=m(),{name:i,contractAddress:A}=l.state||{},{collectible:n,error:S}=b(A,d);return a(r,{children:c(r.Body,{children:[a(s,{left:a(v,{onClick:()=>{e(-1)},children:s.Back})}),c(x,{children:[a(k,{children:i}),a(_,{columns:2,gap:16,children:n?.nfts.length?n.nfts.map(o=>a(B,{title:o.name,onClick:()=>{e(`/nfts/${o.contract_address}`,{state:{type:"detail",tokenId:o.token_id}})},children:a(C,{src:"data:image/gif;base64,R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7",style:{backgroundImage:`url(${o.image_small_url_copy})`}})},`${o.contract_address}-${o.token_id}`)):a(u,{})})]})]})})};export{H as default};
//# sourceMappingURL=index-78b625fa.js.map
