import{bD as w,aV as p,bi as y}from"./index-23cb1aae.js";import{bs as C,bt as v,X as l,a4 as x,bu as S,a3 as r,bv as I,n as e,W as h,o as i,j as c,q as f,aC as B,bh as N,aH as F,aI as D,ad as T,bi as g,as as k}from"./index.html-a1016547.js";import{T as V}from"./index-5f39c8dc.js";const j=async t=>(await w(v,t),await C.push(t),t);let O=(t=21)=>crypto.getRandomValues(new Uint8Array(t)).reduce((o,s)=>(s&=63,s<36?o+=s.toString(36):s<62?o+=(s-26).toString(36).toUpperCase():s>62?o+="-":o+="_",o),"");const U=l.div`
     margin:0px 10px;
`,W=l.h3`
    font-size:24px;
    padding: 15px 0;
    text-align:center;
    margin-top: 8px;
`,b=l.div`
    svg{
        path{
            fill: #4A4A4A!important;
        }
    }
`,E=l(r)`
    --border-top: 0;
    --border-bottom: 0;
    .adm-list-item{
        --padding-left: 0;
        &:nth-of-type(1){
            --border-inner: 0;
        }
    }
    .adm-list-body{
        overflow: inherit;
    }
`,z=()=>{const t=x(),[o,s]=p.useState(!1),{contacts:m}=S(),[d]=r.useForm(),u=I();p.useMemo(()=>u.map(a=>({label:a.name,value:a.id})),[u]);const A=async a=>{try{const n=await j({...a,id:O()});console.log(n),k.show({content:"success"}),s(!1),d.resetFields()}catch(n){k.show({content:n.toString()})}};return e(h,{children:i(h.Body,{children:[e(c,{left:e(b,{onClick:()=>{t(-1)},children:c.Back}),right:e(b,{onClick:()=>{s(!0)},children:c.Add})}),i(U,{children:[e(W,{children:"Address book"}),e(f,{children:m.length?m.map((a,n)=>e(f.Item,{prefix:e(B,{src:N({accountName:a.name,accountAddress:a.address,networkId:a.networkId}),style:{borderRadius:12},fit:"cover",width:24,height:24}),onClick:()=>{d.setFieldsValue({name:a.name,address:a.address}),s(!0)},description:y(a.address),children:a.name},n)):e(F,{})}),e(D,{visible:o,content:e(T,{title:"Add Address",children:i(E,{form:d,onFinish:A,children:[e(r.Item,{name:"name",children:e(g,{placeholder:"Name",autoComplete:"off"})}),e(r.Item,{name:"address",children:e(V,{placeholder:"Starknet Address",rows:4})}),e(r.Item,{name:"networkId",initialValue:"goerli-alpha",children:e(g,{readOnly:!0})})]})}),actions:[[{key:"cancel",text:"Cancel",className:"adm-button-default adm-button-shape-default",onClick:()=>{s(!1)}},{key:"save",text:"Save",className:"adm-button-default adm-button-shape-default",onClick:()=>{d.submit()}}]]})]})]})})};export{z as default};
//# sourceMappingURL=index-5b13cb7f.js.map
