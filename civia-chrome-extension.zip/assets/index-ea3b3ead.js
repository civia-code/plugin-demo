import{aV as t,bK as T,bL as D}from"./index-23cb1aae.js";import{X as r,a4 as F,a3 as a,a5 as w,n as e,W as p,o as n,j as f,a0 as B,bi as o,p as N,bG as V,as as G}from"./index.html-a1016547.js";const L=r.div`
     margin:0px 10px;
`,O=r.h3`
    font-size:24px;
    padding: 15px 0;
    text-align:center;
    margin-top: 8px;
`,j=r.div`
    svg{
        path{
            fill: #4A4A4A!important;
        }
    }
`,E=()=>{const c=F(),[u]=a.useForm(),y=w(),[l,b]=t.useState(),[d,g]=t.useState(!1),[k,R]=t.useState(!1),[x,m]=t.useState(!1),[A,S]=t.useState({}),h=t.useMemo(()=>T(l),[l]),C=async i=>{if(h&&!Reflect.has(i,"name")){m(!0);const s=await V(l,y);m(!1),s&&s.address?(g(!0),S(s),u.setFieldsValue(s)):G.show({content:"error"})}else{const s=await D(A);console.log(s),c(-1)}},v=async()=>{},I=d?k:!h;return e(p,{loading:x,children:n(p.Body,{children:[e(f,{left:e(j,{onClick:()=>{c(-1)},children:f.Back})}),n(L,{children:[e(O,{children:"Add tokens"}),e("div",{children:n(a,{form:u,footer:e(B,{block:!0,type:"submit",disabled:I,style:{borderRadius:"20px",padding:"10px 0"},children:"Continue"}),onFinish:C,onValuesChange:v,children:[e(a.Item,{name:"address",label:"Contract address",children:e(o,{autoFocus:!0,onChange:i=>{b(i.toLowerCase())},readOnly:d,autoComplete:"off"})}),d?n(N,{children:[e(a.Item,{name:"name",label:"Name",children:e(o,{type:"input",readOnly:!0})}),e(a.Item,{name:"symbol",label:"Symbol",children:e(o,{readOnly:!0})}),e(a.Item,{name:"decimals",label:"Decimals",children:e(o,{readOnly:!0})})]}):null]})})]})]})})};export{E as default};
//# sourceMappingURL=index-ea3b3ead.js.map
