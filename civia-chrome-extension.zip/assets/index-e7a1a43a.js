import{aV as c,b5 as Q,bd as V,L as O,bi as Y}from"./index-23cb1aae.js";import{n as t,af as ee,ah as te,ae,ai as B,o as y,aP as se,X as d,a4 as ne,a5 as re,Y as le,aN as oe,r as ie,aQ as ce,Z as de,aR as ue,W as z,j as P,aD as he,aS as E,aT as H,aU as fe,m as j,ad as W,$ as ge,a0 as pe,aV as me,aW as ye,as as u}from"./index.html-a1016547.js";import{u as ve}from"./use-gesture-react.esm-e2caa223.js";const we=()=>t("svg",{viewBox:"0 0 42 40",height:"1em",xmlns:"http://www.w3.org/2000/svg",style:{verticalAlign:"-0.125em"},children:t("path",{d:"m21 34-10.52 5.53a2 2 0 0 1-2.902-2.108l2.01-11.714-8.511-8.296a2 2 0 0 1 1.108-3.411l11.762-1.71 5.26-10.657a2 2 0 0 1 3.586 0l5.26 10.658L39.815 14a2 2 0 0 1 1.108 3.411l-8.51 8.296 2.009 11.714a2 2 0 0 1-2.902 2.109L21 34Z",fill:"currentColor",fillRule:"evenodd"})}),h="adm-rate",Se={count:5,allowHalf:!1,character:t(we,{}),defaultValue:0,readOnly:!1,allowClear:!0},xe=v=>{const a=ee(Se,v),[f,w]=te(a),S=c.useRef(null),L=Array(a.count).fill(null);function g(n,o){return t("div",{className:B(`${h}-star`,{[`${h}-star-active`]:f>=n,[`${h}-star-half`]:o,[`${h}-star-readonly`]:a.readOnly}),role:"radio","aria-checked":f>=n,"aria-label":""+n,children:a.character})}const x=ve(n=>{if(a.readOnly)return;const{xy:[o],tap:C}=n,p=S.current;if(!p)return;const b=p.getBoundingClientRect(),m=(o-b.left)/b.width*a.count,A=a.allowHalf?Math.ceil(m*2)/2:Math.ceil(m),N=se(A,0,a.count);if(C&&a.allowClear&&N===f){w(0);return}w(N)},{axis:"x",pointer:{touch:!0},filterTaps:!0});return ae(a,t("div",{...Object.assign({className:B(h,{[`${h}-half`]:a.allowHalf}),role:"radiogroup","aria-readonly":a.readOnly,ref:S},x()),children:L.map((n,o)=>y("div",{className:B(`${h}-box`),children:[a.allowHalf&&g(o+.5,!0),g(o+1,!1)]},o))}))},be=xe,Ae=d.div`
    svg{
        path{
            fill: #4A4A4A!important;
        }
    }
`,Le=d.div`
     margin:0 32px;
     position: relative;
     .adm-card-body {
        padding: 0;
    }
     .adm-list-body{
        --border-bottom: 0px;
     }
     .adm-dropdown-item-title-text {
        font-size: 16px;
        font-weight: bold;
     }
`,Ce=d.h1`
  text-align: center;
  margin-top: 20px;
`,Ne=d.div`
  display: flex;
  justify-content: center;
  align-items: center;
  margin-top: 5px;
`,ke=d.h2`
  margin-left: 10px;
`,Ge=d.div`
  background: #fff;
  border-radius: 5px;
  /* padding-top: 20px; */
  /* padding-bottom: 20px; */
`,Re=d.div`
  width: 11%;
  font-size: 30px;
  position: absolute;
  top: 68px;
  left: 70%;
`,Ve=d(pe)`
  width: 90%;
  margin-left: 50%;
  transform: translateX(-50%);
  margin-top: 40px;
  margin-bottom: 20px;
  border-radius: 20px;
`,Be=d(W)`
    .adm-card-body{
        max-height: 200px;
        overflow: scroll;
        scroll-behavior:smooth;
        ::-webkit-scrollbar {
            display: none;
        }
    }
`,Oe=()=>{const v=ne(),a=re(),f=a&&Q(a),{accountInfoData:w={}}=le(a,a.address),{nickName:S=null}=w,[L,g]=c.useState(!1),x=[{level:1,name:"Secruity level 1"},{level:2,name:"Secruity level 2"}],[n,o]=c.useState(1),[C,p]=c.useState("Secruity level 1"),{mapAddress2Id:b}=oe(),m=`${a?.address},guardians`,[A,N]=c.useState(V.get(m)||[]),[l,T]=c.useState(A.length),{transactions:_}=ie(a),$=_.some(e=>["ACCEPTED_ON_L1","ACCEPTED_ON_L2"].includes(e.status)&&e.meta?.title==="Add guardians"&&e.meta?.transactions[0].calldata.length>1),{data:U={followingData:[],followersData:[]},isValidating:M}=ce(()=>me().then(e=>{if(e)return e;{const s=V.get(`@"${f}","socalList"`);return s?JSON.parse(s):{followingData:[],followersData:[]}}}),{key:`@"${f}","socalList"`,revalidateOnFocus:!1,revalidateOnReconnect:!1,refreshInterval:6e4,dedupingInterval:1e4}),{followingData:k}=U,[i,G]=c.useState([]),I=de().filter(e=>{const{transactions:[{calldata:s,entrypoint:r,contractAddress:K}]}=e.payload;return r==="addGuardians"?O(K,a.address):!1});c.useEffect(()=>{o(l>0?2:1),p(l>0?"Secruity level 2":"Secruity level 1")},[l]),c.useEffect(()=>{$&&T(3),ue().then(e=>{T(s=>Math.max(e,s))})},[$]);const R=k.reduce((e,s)=>{for(const r of A)r&&O(s.address,r.addressResult)&&e.push(s);return e},[]),D=(()=>{if(console.log("isValid: guardiansSize ---",l),n===1)switch(l){case-1:return!0;case 0:return i.length===1;case 1:return!1;case 2:return!1;case 3:return!1;default:return!0}if(n===2)switch(l){case-1:return!0;case 0:return i.length===3;case 1:return i.length===2;case 2:return i.length===1;case 3:return!1;default:return!0}})(),X=()=>{console.log("checkValue",i),D&&(g(!0),ye(i.length,i,a).then(e=>{console.log("changeGuardiansTrans -----",e)}).catch(e=>{u.show({content:String(e)})}).finally(()=>{g(!1)}))},F=e=>{const s=[];for(const r of i)s.push({address:Z(Y(r),b(r)).substring(1),addressResult:r});for(const r of R)s.push({address:"",addressResult:r.address});V.set(m,s),v(-1)},Z=(e,s)=>s?`#${s}`:"#",q=e=>{if(!e||!e.length){console.log("no guard"),G([]);return}const[s]=R.filter(r=>e.includes(r.address));if(s){u.show(`${s.nickname} is guardian already!`);return}if(n===1&&l===0&&e.length>1){u.show({content:"Select at most one guardian when level one!"});return}if(n===1&&l>0){u.show({content:"Select at most one guardian when level one!"});return}if(n===2&&l===0&&e.length>3){u.show({content:"Select at most three guardians when level two!"});return}if(n===2&&l===1&&e.length>2){u.show({content:"Select at most three guardians when level two!"});return}if(n===2&&l===2&&e.length>1){u.show({content:"Select at most three guardians when level two!"});return}if(n===2&&l===3&&e.length>0){u.show({content:"Select at most three guardians when level two!"});return}return G(e),!0},J=e=>{console.log("e",e);const s=x.find(r=>r.level===e);s&&(console.log("result",s),G([]),o(s.level),p(s.name))};return t(z,{loading:L,children:y(z.Body,{children:[t(P,{left:t(Ae,{onClick:()=>{v(-1)},children:P.Back})}),y(Le,{children:[t(Ce,{children:"Guardians"}),y(Ne,{children:[t("img",{style:{width:20,height:20,borderRadius:"50%"},src:he({accountAddress:a?.address})}),t(ke,{children:S})]}),y(Ge,{children:[t(E,{children:t(E.Item,{title:C,children:t("div",{style:{padding:20},children:t(H.Group,{defaultValue:n,onChange:J,children:t(fe,{direction:"vertical",block:!0,children:x.map(e=>t(H,{style:{"--icon-size":"22px","--font-size":"16px","--gap":"8px"},block:!0,value:e.level,disabled:l>1&&e.level===1,children:e.name},e.level))})})})},"1")}),t(Re,{children:t(be,{allowHalf:!0,value:n/2,count:1,readOnly:!0,style:{"--star-size":"20px",marginLeft:5}})}),t(Be,{title:"Followings",children:t(j,{gridType:"listCheck",list:k,isValidating:M,checkValue:i,handleCheckChange:q})}),t(W,{title:"Current Guardians",children:t(j,{gridType:"listNoNav",currentList:R,list:k.filter(e=>i.includes(e?.address))})})]}),t("div",{style:{paddingBottom:"16px"},children:t(Ve,{block:!0,color:"primary",size:"large",onClick:X,disabled:!D,children:"Add Guardians"})})]}),I.length>0?t(ge,{actions:I,onApprove:F,simple:!0}):null]})})};export{Oe as default};
//# sourceMappingURL=index-e7a1a43a.js.map
