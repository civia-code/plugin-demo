import{aV as x}from"./index-23cb1aae.js";import{X as e,a4 as u,bm as b,n as t,W as d,o as y,j as s,aZ as v,a3 as l,bi as f,bn as S,a0 as w,as as c,bo as I}from"./index.html-a1016547.js";const k=e.div`
    background: rgba(249, 255, 247, 1);
    --body-wrapper-background: rgba(249, 255, 247, 1);
    height:100%;
    left:0;
    top:0;
    width:100%;
    min-height:100vh;
    border:1px solid transparent;
`,A=e.div`
    padding: 20px 0 10px;
    text-align:center;
    svg{
        width:56px;
        height:56px;
        display:inline-block;
        margin:auto;
        path{
            fill: var(--color-primary)!important;
        }
    }
`,B=e(S)`
    path {
        fill: #4A4A4A;
    }
`,C=e.h3`
    font-size:24px;
    padding: 15px 0;
    text-align:center;
    margin-top: 8px;
`,W=e.div`
    min-height:320px;
    margin: 10px 0;
`,j=e(l)`
    padding: 40px 0;
    ---border-inner: 0;
    ---border-top: 0;
    ---border-bottom: 0;
    .adm-list-body{
        --adm-color-background: transparent;
    }
    .adm-form-item{
        margin:23px
    }
    .adm-list-item-content-main{
        padding: 6px 25px;
        background:rgba(232, 232, 232, 0.5);
        border-radius:18px;
    }
`,z=e.div`
    text-align:center;
    margin-top:30px;
`,E=e(w)`
    height:60px;
    border-radius:30px;
    width:242px;
    margin:4px auto;
    line-height: unset;
    .adm-button-loading-wrapper {
        flex-direction: column;
    }
`,N=()=>{const[p,o]=x.useState(!1),a=u(),{setInviteInfo:g}=b(),h=async m=>{const{inviteCode:n}=m;if(!/^\d{6,10}$/.test(n))c.show({content:"Please Enter valid code!"});else{o(!0);const r=await I(n),[i]=Array.isArray(r)?r:[];o(!1),i?(g(n,i,""),a("/onboarding/password")):c.show({content:`${n} is not exist!`})}};return t(k,{children:t(d,{children:y(d.Body,{children:[t(s,{left:t("div",{onClick:()=>{a(-1)},children:t(s.Icon,{children:t(B,{})})})}),t(A,{children:t(v,{})}),t(C,{children:"Create Account"}),t(W,{children:t(j,{footer:t(z,{children:t("div",{children:t(E,{block:!0,type:"submit",color:"primary",size:"large",loading:p,children:"Commit"})})}),onFinish:h,layout:"horizontal",children:t(l.Item,{name:"inviteCode",children:t(f,{placeholder:"Enter your invite code",type:"text",maxLength:30,autoComplete:"false"})})})})]})})})};export{N as default};
//# sourceMappingURL=index-b1478e57.js.map
