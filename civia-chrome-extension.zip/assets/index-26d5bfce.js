import{b9 as G,b1 as X,aV as c,b7 as Y,R as Z,bh as ee,L as k,ay as te,r as L,aC as ae}from"./index-23cb1aae.js";import{X as s,_ as V,a3 as w,a0 as E,s as se,o as x,p as ne,n as e,ad as F,bi as R,as as v,aK as re,aF as M,aE as _,aA as oe,a4 as ie,u as de,a5 as ce,W as N,j as I,aZ as le,aQ as he,br as ue,aY as ge,ax as pe,m as B,aR as me,L as ye,q as be,aO as Se,a_ as O,b0 as fe,b3 as we,b4 as xe,b2 as ve}from"./index.html-a1016547.js";const ke=s.div`
    min-height:320px;
    margin: 10px 0;
`,Ae=s(w)`
    padding: 20px 0;
    ---border-inner: 0;
    ---border-top: 0;
    ---border-bottom: 0;
    .adm-list-body{
        --adm-color-background: transparent;
    }
    .adm-form-item{
        margin:23px
    }
    .adm-list-item-content-main{
        padding: 6px 25px;
        background:rgba(232, 232, 232, 0.5);
        border-radius:18px;
    }
`,Ce=s(E)`
    height:44px;
    margin:4px auto;
    line-height: unset;
    border-radius:20px;
`,Le=s(V.Item)`
    text-align: center;
`,Re=s(V)`
    padding: 12px;
    text-align:center;
`,Ne=s.div`
    >div:nth-child(1){
        position:fixed;
        bottom:0;
        z-index:1000;
        left:0;
        right:0;
        max-width:750px;
        margin:auto;
    }
    >div:nth-child(2){
        display:block;
        height:73px;
        width:1px;
        opacity:transparent;
    }
    .adm-tab-bar-wrap{
        min-height:73px;
        border-top:1px solid rgba(57, 92, 62, 0.34); 
    }
    .adm-tab-bar-item{
        transition: background 1s cubic-bezier(0.075, 0.82, 0.165, 1);
        .adm-tab-bar-item-icon{
            height:unset;
            line-height:unset;
        }
    }
`,Ie=()=>{const[a]=w.useForm(),{switcherNetworkId:r}=se();return x(ne,{children:[e(ke,{children:e(Ae,{onFinish:async u=>{const{password:o,password2:b}=u;if(!/^\w{6,30}$/.test(o))v.show({content:"Password must be 6-30 characters of numbers or letters!",duration:3e3});else if(!o||o!==b)v.show({content:"The two entered passwords do not match!",duration:3e3});else{const h=await re(r,o);M(h),_.setState({selectedAccount:h,showMigrationScreen:h?G(h):!1})}},layout:"horizontal",form:a,children:x(F,{children:[e(w.Item,{name:"password",children:e(R,{placeholder:"Passsword",type:"password",maxLength:20})}),e(w.Item,{name:"password2",children:e(R,{placeholder:"Enter your password again",type:"password",maxLength:20})})]})})}),e(Ne,{children:e("div",{children:e(Re,{columns:1,gap:8,children:e(Le,{children:e(Ce,{block:!0,color:"primary",size:"large",onClick:()=>{a.submit()},children:"Continue"})})})})})]})},{decodeShortString:Be}=ae,Oe=s.div`
    background: rgba(249, 255, 247, 1);
    --body-wrapper-background: rgba(249, 255, 247, 1);
    height:100%;
    left:0;
    top:0;
    width:100%;
    min-height: 100vh;
    border:1px solid transparent;
`,Te=s.div`
    svg{
        path{
            fill: #4A4A4A!important;
        }
    }
`,ze=s.div`
    
`,Ge=s.div`
    padding: 20px 0 10px;
    text-align:center;
    svg{
        width:56px;
        height:56px;
        display:inline-block;
        margin:auto;
        path{
            fill: var(--color-primary)!important;
        }
    }
`,T=s(be)`
    --adm-color-background: transparent;
    margin:20px 10px;
`,z=s(F)`
    ::-webkit-scrollbar {
        display: none;
    }
`,Ve=s.h3`
    font-size:24px;
    padding: 15px 0;
    text-align:center;
    margin-top: 8px;
`,Ee=s(E)`
    height:40px;
    border-radius:20px;
    width:242px;
    margin:4px auto;
    line-height: unset;
`,Fe=s.div`
    padding: 10px 0;
`,Me=a=>a.map(r=>new oe({address:r.address,network:r.network,signer:r.signer,hidden:r.hidden,type:r.type})),Ke=()=>{const a=ie(),r=de(),l=ce(),u=X(te),[o]=c.useMemo(()=>u.filter(Y(r.id??Z.id)).reduce(([h,S],p)=>(p.hidden?S.push(p):h.push(p),[h,S]),[[],[]]),[u,r.id]),b=Me(o);return e(Oe,{children:e(N,{children:x(N.Body,{children:[e(I,{left:e(Te,{onClick:()=>{a(-1)},children:I.Back})}),e(Ge,{children:e(le,{})}),e(Ve,{children:"Social Recovery"}),l?e(_e,{account:l,mapedAccount:b}):e(Ie,{})]})})})},_e=({account:a,mapedAccount:r})=>{const l=ee(a?.address),u=`${l},guardians`,[o,b]=c.useState(JSON.parse(window.localStorage.getItem(u))||["",[]]),[h,S]=c.useState(!1),[p,P]=c.useState(!1),[d,W]=c.useState(o[0]),[g,q]=c.useState(o[1]),[A,J]=c.useState(1),[K,U]=c.useState(),{data:C,isValidating:j,mutate:Pe}=he(()=>Se(a?.address,1,200).then(t=>{if(t&&t?.length){const i=[];for(let n=0;n<t[0].length;n++)t[0][n].length>10&&i.push({address:L.toHex(t[0][n]),accountId:L.hexToDecimalString(t[1][n]),nickname:Be(t[2][n])});return i}}),{key:"allAccount",revalidateOnFocus:!1,revalidateOnReconnect:!1});c.useEffect(()=>{const t=r.filter(i=>k(i.address,d))||[];t.length>0&&(_.setState({selectedAccount:t[0],showMigrationScreen:a?G(a):!1}),M(t[0]),U(t[0]))},[r,d,a]),c.useEffect(()=>{p&&ue({oldOwnerAddress:d})},[p,d]);const D=async()=>{a&&(S(!0),O({fromLocal:!0}).then(t=>{if(t){const i={oldOwnerAddress:d,newOwnerPubKey:t,type:98,tx:null};for(const n of g)fe({account:a.address,from:a.address,to:n,title:"Account recover request",content:JSON.stringify(i)}).then(()=>{window.localStorage.setItem(u,JSON.stringify([d,g])),b([d,g])}).catch(m=>{v.show({content:JSON.stringify(m)})})}else return"Unknow Error"}).then(t=>{v.show({content:"Success"})}).finally(()=>{S(!1)}))},$=ge(async()=>{if(console.log("wait messge"),l&&o[0].length>=10){await we({account:l});const t=await xe({account:l,limit:10,page_no:1}).then(i=>{const n=i.result.messages,m=[];return n.reduce((f,y)=>(m.includes(y.from)||g.some(Q=>k(Q,y.from))&&(m.push(y.from),f.push({...y,content:JSON.parse(y.content),timestamp:new Date(y.timestamp).getTime()})),f),[]).filter(f=>f.content.msgType===99)});if(t.length){const{newOwnerPubKey:i}=t[0].content.res;O({accountAddress:d}).then(n=>{n&&Array.isArray(n)&&k(n[0],i)&&(P(!0),$(),t.forEach(m=>{ve({account:l,message_id:m.message_id})}))})}}},5e3),H=d&&(A===1&&g.length>=1||A===3&&g.length>=2);return K?e(pe,{to:"/account/home"}):x(ze,{children:[e(T,{mode:"card",header:"Account to recover",children:e(z,{style:{height:220,overflow:"scroll"},children:e(B,{gridType:"listRadio",list:C,checkValue:d,handleCheckChange:t=>{W(t),me(t).then(i=>{J(i||1)})}})})}),e(T,{mode:"card",header:"Guardians",children:e(z,{style:{height:220,overflow:"scroll"},children:e(B,{gridType:"listCheck",list:C,checkValue:g,handleCheckChange:t=>{q(t)}})})}),e(Fe,{children:e(Ee,{block:!0,type:"submit",color:"primary",size:"large",loadingText:"creating",onClick:D,disabled:!H||o[0].length>10,children:"Submit recovery request"})}),e(ye,{visible:h||j||o[0].length>10})]})};export{Ke as default,Me as mapWalletAccountsToAccounts};
//# sourceMappingURL=index-26d5bfce.js.map
