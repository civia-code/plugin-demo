import{X as n,a4 as c,a5 as d,u as l,o as a,n as e,al as u,q as t,ar as h,as as m}from"./index.html-a1016547.js";import{bh as g}from"./index-23cb1aae.js";const p=n.div`
    min-height:320px;
    margin: 10px 0;
`,k=n(t)`
    margin: 0 20px;
`,f=n.h3`
    font-size:24px;
    padding: 15px 0;
    text-align:center;
    margin-top: 8px;
`,w=()=>{const o=c(),r=d(),s=l(),i=()=>{m.show({content:"copyed"}),setTimeout(()=>{chrome.tabs.create({url:"https://faucet.goerli.starknet.io/"})},500)};return a("div",{children:[e(u,{back:"back",onBack:()=>{window.history.go(-1)}}),e(f,{children:"How would you like to fund your account?"}),e(p,{children:a(k,{children:[e(t.Item,{description:"Is coming soon!",disabled:!0,children:"Buy with card or bank transfer"}),e(t.Item,{onClick:()=>{o("/tokens/funding_qrcode")},arrow:!1,children:"From another StarkNet account"}),e(t.Item,{onClick:()=>{o("/tokens/funding_bridge")},children:"Bridge from Ethereum and other chains"}),s?.id==="goerli-alpha"?e(h,{onCopy:()=>i(),text:g(r.address),children:e(t.Item,{arrow:!1,children:"Faucet"})}):null]})})]})};export{w as default};
//# sourceMappingURL=index-9a724f27.js.map
