import{aV as m}from"./index-23cb1aae.js";import{X as r,a4 as x,a5 as g,b6 as u,o as n,n as a,al as b,a3 as f,bi as y,q as s,h as v,b8 as S,b7 as k}from"./index.html-a1016547.js";import{a as I}from"./throttle-bdc409b7.js";const B=r.div`
    min-height:320px;
    margin: 10px 0;
`,T=r.div`
    margin: 30px 20px;
    border: 1px solid #efefef;
    padding: 10px 5px;
    border-radius: 5px;
`,E=()=>{const t=x(),i=g(),{tokenDetails:o}=u(i),[c,d]=m.useState(/.*/),l=I(e=>{d(new RegExp(e,"gi"))},300),p=({address:e})=>{t(`/tokens/${e}`,{state:{type:"send"}})};return n("div",{children:[a(b,{back:"back",onBack:()=>{t(-1)},children:"Send"}),a(B,{children:n(f,{style:{"--border-bottom":"0px","--border-top":"0px"},children:[a(T,{children:a(y,{placeholder:"Search",onChange:l})}),a(s,{mode:"card",children:o.filter(e=>c?.test(e.name)).map((e,h)=>a(s.Item,{description:e.symbol,prefix:a("div",{style:{lineHeight:"100%"},children:a(v,{...S(e),url:e.image,size:30})}),extra:a("div",{children:k(e)}),onClick:()=>{p(e)},children:e.name},h))})]})})]})};export{E as default};
//# sourceMappingURL=index-6a72e341.js.map
