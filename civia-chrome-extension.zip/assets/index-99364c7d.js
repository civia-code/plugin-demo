import{X as s,a4 as r,a5 as c,aB as i,o as d,n as e,al as l,q as t,aG as m,ar as p,as as h,a0 as u}from"./index.html-a1016547.js";import{bJ as x}from"./index-23cb1aae.js";import{QrCode as g}from"./index-9d11c242.js";const y=s.div`
    min-height:320px;
    margin: 10px 0;
`,b=s(t)`
    text-align:center;
    --border-top: 0;
    --border-bottom: 0;
    --border-inner: 0;
`,f=s.h3`
    font-size:24px;
    padding: 15px 0;
    text-align:center;
    margin-top: 8px;
`,v=s.div`
    padding: 10px 30px;
`,k=()=>{const n=r(),a=c(),{accountNames:o}=i();return d("div",{children:[e(l,{back:"back",onBack:()=>{n(-1)}}),e(y,{children:d(b,{children:[e(t.Item,{children:e(g,{size:220,data:a?.address})}),e(t.Item,{children:e(f,{children:m(a,o)})}),e(t.Item,{children:e(v,{children:x(a.address)})}),e(t.Item,{children:e(p,{onCopy:()=>h.show("copyed"),text:a.address,children:e(u,{size:"small",children:"Copy address"})})})]})})]})};export{k as default};
//# sourceMappingURL=index-99364c7d.js.map
