import{aV as y,b5 as w,bd as A}from"./index-23cb1aae.js";import{n as a,a9 as C,X as l,a4 as L,aa as S,a5 as T,aQ as k,o as t,W as s,A as F,j as u,p as I,q as m,aX as P,c as B,i as o,m as g,L as f,aH as p,aV as D}from"./index.html-a1016547.js";const j=l.div`
    /* min-height:320px;
    margin: 10px 0;
    border-radius: 20px 20px 0 0;
    background:#fff; */
    padding-top: 24px;
`,H=l(o)`
    .adm-tabs-tab-line{
        
    }
`,O=l(m)`
    --border-top: 0px;
    --border-bottom: 0px;
    font-size:12px!important;
`,V=()=>{const h=L();S("socal");const[b,v]=y.useState("following"),n=T(),i=n&&w(n),{data:x={followingData:[],followersData:[]},isValidating:r,mutate:W}=k(()=>D().then(e=>e||A.get(`@"${i}","socalList"`)||{}),{key:`@"${i}","socalList"`,revalidateOnFocus:!1,revalidateOnReconnect:!1,refreshInterval:1e4,dedupingInterval:1e4}),{followingData:c=[],followersData:d=[]}=x||{};return t(s,{children:[a(s.Head,{children:t(F,{children:[a(u,{right:a(u.AddPanel,{children:e=>t(I,{children:[e,a(m.Item,{prefix:a(P,{}),onClick:()=>{h("/account/secruity_level")},arrow:!1,children:"Guardians"})]})})}),a(B,{}),t(H,{onChange:e=>v(e),children:[a(o.Tab,{title:"Followings"},"following"),a(o.Tab,{title:"Followers"},"followers")]})]})}),a(s.Body,{children:a(j,{children:a("div",{children:b==="following"?c.length?a(g,{gridType:"list",list:c}):r?a(f,{visible:!0,mask:!1}):a(p,{}):a(O,{children:d.length?a(g,{gridType:"list",list:d}):r?a(f,{visible:!0,mask:!1}):a(p,{})})})})})]})},N=()=>a(C,{children:a(V,{})});export{N as default};
//# sourceMappingURL=index-a5722661.js.map
