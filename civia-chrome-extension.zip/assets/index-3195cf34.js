import{aV as c,b5 as x}from"./index-23cb1aae.js";import{n as e,a9 as b,X as n,a4 as h,a5 as w,aa as v,aM as y,o,W as l,A as C,c as k,i as s,aC as A,L as S,aH as T,_ as B,ad as L,a0 as E}from"./index.html-a1016547.js";import{u as _}from"./useCollections-cb9cca63.js";import"./aspect.service-1342d8b4.js";import"./useNfts-8eacf436.js";const N=n.div`
    min-height:320px;
    padding: 20px 10px;
`,P=n(B)`
    padding: 0 32px;
`,G=n(L)`
    border-radius: 0;
    border-bottom: 1px solid #395C3E;
    &:hover{
        cursor: pointer;
    }
    .adm-card-body{
        padding: 0;
    }

    .adm-image{
        width: 130px;
        height: 130px;
        border-radius:10px;
        overflow:hidden;
    }

    .info{
        width: 130px;
        font-size: 14px;
        font-weight: 400;
        line-height:19px;
        overflow: hidden;
        text-overflow: ellipsis;
        margin: 8px 0;
        span{
            width: 130px;
            display: inline-block;
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
        }
    }
`;n(E)`
    margin: 20px auto;
    display: block;
    border-radius:100%;
    overflow:hidden;
    line-height:inherit;
    border-radius:20px;
    width: 128px;
    padding: 10px 12px;
`;const H=()=>{const a=h(),i=w();return i?e(I,{account:i}):(a("/account/list"),null)},I=({account:a})=>{const i=h(),[m,p]=c.useState(!1),[u,f]=c.useState([]),d=_(a);return v("tokens"),a&&x(a),c.useEffect(()=>{const t=d&&d.length?d[0]?.nfts:[];for(const r of t)p(!0),y.get(`${r.token_uri}${r.token_id}`).then(g=>{r.image_uri=g.data.image}).finally(()=>{p(!1)});console.log("list -----",t),f(t)},[]),o(l,{children:[e(l.Head,{children:o(C,{children:[e(k,{}),o(s,{onChange:t=>{switch(t){case"1":i("/account/tokens");break;case"2":i("/account/nfts");break}},defaultActiveKey:"3",children:[e(s.Tab,{title:"Tokens"},"1"),e(s.Tab,{title:"NFTs"},"2"),e(s.Tab,{title:"SBTs"},"3")]})]})}),e(l.Body,{children:e(N,{children:u.length?e(P,{columns:2,gap:16,children:u.map(t=>o(G,{children:[e(A,{src:t.image_uri||"https://img1.baidu.com/it/u=252746894,533082394&fm=253&fmt=auto&app=138&f=JPEG?w=343&h=337"}),e("div",{className:"info",children:e("div",{children:e("span",{children:t.contract?.name})})})]},t))}):m?e(S,{visible:!0}):e(T,{})})})]})},J=()=>e(b,{children:e(H,{})});export{J as default};
//# sourceMappingURL=index-3195cf34.js.map
