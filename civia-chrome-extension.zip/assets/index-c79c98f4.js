import{aV as e}from"./index-23cb1aae.js";import{X as r,a4 as x,by as w,n as t,W as o,o as s,j as c,q as l,bz as f,ac as n}from"./index.html-a1016547.js";import{S as k}from"./index-14b29165.js";const E=a=>e.createElement("svg",{xmlns:"http://www.w3.org/2000/svg",xmlnsXlink:"http://www.w3.org/1999/xlink",width:21,height:21,viewBox:"0 0 21 21",fill:"none",...a},e.createElement("defs",null,e.createElement("rect",{id:"path_0",x:0,y:0,width:21,height:21})),e.createElement("g",{opacity:1,transform:"translate(0 0)  rotate(0 10.5 10.5)"},e.createElement("mask",{id:"bg-mask-0",fill:"white"},e.createElement("use",{xlinkHref:"#path_0"})),e.createElement("g",{mask:"url(#bg-mask-0)"},e.createElement("path",{id:"\\u5206\\u7EC4 1",fillRule:"evenodd",style:{fill:"#4A4A4A"},transform:"translate(1.2447778505857734 0.33708775488280107)  rotate(0 9.255242780273438 10.33162131298828)",opacity:1,d:"M9.16 13.15C9.19 13.15 9.22 13.15 9.25 13.15C9.28 13.15 9.31 13.15 9.34 13.15C13.17 13.19 16.32 15.92 16.84 19.63C16.84 19.66 16.83 19.69 16.83 19.73L16.84 19.8C16.84 20.27 17.21 20.65 17.67 20.65C18.14 20.65 18.51 20.27 18.51 19.8L18.5 19.73C18.5 19.63 18.48 19.53 18.45 19.44C17.99 16.06 15.73 13.32 12.67 12.14C14.47 10.98 15.64 8.93 15.64 6.58C15.64 2.94 12.84 0 9.25 0C5.65 0 2.86 2.94 2.86 6.58C2.86 8.93 4.03 10.98 5.83 12.14C2.74 13.34 0.47 16.1 0.04 19.52C0.02 19.59 0.01 19.65 0.01 19.72C0.01 19.75 0 19.77 0 19.8L0.02 19.8L0.02 19.8C0.02 20.28 0.4 20.66 0.87 20.66C1.34 20.66 1.72 20.28 1.72 19.8L1.71 19.73C1.71 19.65 1.69 19.57 1.68 19.5C2.25 15.86 5.37 13.19 9.16 13.15Z M9.2434 1.60652C6.5234 1.60652 4.3234 3.83652 4.3234 6.57652C4.3234 9.32652 6.5234 11.5565 9.2434 11.5565C11.9634 11.5565 14.1634 9.32652 14.1634 6.57652C14.1634 3.83652 11.9634 1.60652 9.2434 1.60652Z "})))),L=a=>e.createElement("svg",{xmlns:"http://www.w3.org/2000/svg",xmlnsXlink:"http://www.w3.org/1999/xlink",width:22,height:22,viewBox:"0 0 22 22",fill:"none",...a},e.createElement("defs",null,e.createElement("rect",{id:"path_0",x:0,y:0,width:22,height:22}),e.createElement("rect",{id:"path_1",x:0,y:0,width:26,height:26})),e.createElement("g",{opacity:1,transform:"translate(0 0)  rotate(0 11 11)"},e.createElement("mask",{id:"bg-mask-0",fill:"white"},e.createElement("use",{xlinkHref:"#path_0"})),e.createElement("g",{mask:"url(#bg-mask-0)"},e.createElement("g",{opacity:1,transform:"translate(-2 -2)  rotate(0 13 13)"},e.createElement("mask",{id:"bg-mask-1",fill:"white"},e.createElement("use",{xlinkHref:"#path_1"})),e.createElement("g",{mask:"url(#bg-mask-1)"},e.createElement("path",{id:"\\u5206\\u7EC4 1",fillRule:"evenodd",style:{fill:"#4A4A4A"},transform:"translate(3.4125000000002252 2.924999999999546)  rotate(0 9.628125 10.034374999999999)",opacity:1,d:"M6.34 15.44C6.34 14.62 6.99 13.97 7.8 13.97C8.61 13.97 9.26 14.62 9.26 15.44C9.26 16.25 8.61 16.9 7.8 16.9L7.23 18.28L9.02 20.07L10.16 20.07L12.59 17.63C13.16 18.44 14.14 19.01 15.19 19.01C16.9 19.01 18.28 17.63 18.28 15.92C18.28 14.87 17.71 13.89 16.9 13.32L19.26 10.97L19.26 9.83L15.27 5.85C16.25 5.28 16.9 4.31 16.9 3.09C16.9 1.38 15.52 0 13.81 0C12.59 0 11.54 0.65 11.05 1.62L10.24 0.81L9.1 0.81L5.85 4.06L6.34 5.44C6.99 5.53 7.56 6.18 7.56 6.91C7.56 7.72 6.91 8.37 6.09 8.37C5.36 8.37 4.71 7.88 4.63 7.15L3.25 6.66L0 9.91L0 11.05L4.96 16.01L6.34 15.44Z M13.6462 4.63625L13.7362 4.63625C14.5463 4.63625 15.1962 3.97625 15.1962 3.16625C15.1962 2.35625 14.5463 1.70625 13.7362 1.70625C12.9163 1.70625 12.2663 2.35625 12.2663 3.16625L12.2663 3.24625L10.8863 3.89625L9.58625 2.59625L7.79625 4.38625C8.61625 4.95625 9.09625 5.84625 9.09625 6.90625C9.09625 8.61625 7.71625 9.99625 6.01625 9.99625C4.95625 9.99625 4.06625 9.50625 3.49625 8.69625L1.70625 10.4763L5.11625 13.8962C5.68625 12.9963 6.66625 12.3463 7.79625 12.3463C9.50625 12.3463 10.8863 13.7263 10.8863 15.4362C10.8863 16.5763 10.2362 17.5462 9.34625 18.1162L9.58625 18.3662L12.2663 15.6763L13.6462 16.1663C13.7362 16.8962 14.3763 17.4662 15.1163 17.4662C15.9263 17.4662 16.5763 16.8162 16.5763 16.0063C16.5763 15.2762 16.0063 14.6263 15.2762 14.5463L14.7863 13.1663L17.4662 10.4763L12.9963 6.01625L13.6462 4.63625Z "})))))),h=a=>e.createElement("svg",{xmlns:"http://www.w3.org/2000/svg",xmlnsXlink:"http://www.w3.org/1999/xlink",width:21,height:21,viewBox:"0 0 21 21",fill:"none",...a},e.createElement("defs",null,e.createElement("rect",{id:"path_0",x:0,y:0,width:21,height:21}),e.createElement("rect",{id:"path_1",x:0,y:0,width:21,height:21})),e.createElement("g",{opacity:1,transform:"translate(0 0)  rotate(0 10.5 10.5)"},e.createElement("mask",{id:"bg-mask-0",fill:"white"},e.createElement("use",{xlinkHref:"#path_0"})),e.createElement("g",{mask:"url(#bg-mask-0)"},e.createElement("g",{opacity:1,transform:"translate(0 0)  rotate(0 10.5 10.5)"},e.createElement("mask",{id:"bg-mask-1",fill:"white"},e.createElement("use",{xlinkHref:"#path_1"})),e.createElement("g",{mask:"url(#bg-mask-1)"},e.createElement("path",{id:"\\u5206\\u7EC4 1",fillRule:"evenodd",style:{fill:"#4A4A4A"},transform:"translate(1.1908073583985601 1.1908072763671615)  rotate(0 9.309910456054686 9.30991045605461)",opacity:1,d:"M16.58 18.6241C17.71 18.6141 18.62 17.7041 18.62 16.5841L18.62 12.5141C18.62 11.3841 17.71 10.4741 16.58 10.4741L2.04 10.4741C0.91 10.4741 0 11.3841 0 12.5141L0 16.5841C0 17.7041 0.91 18.6141 2.04 18.6241L16.58 18.6241Z M1.74592 12.5091L1.74592 16.5791C1.74592 16.7491 1.87592 16.8791 2.03592 16.8791L16.5859 16.8791C16.7459 16.8791 16.8759 16.7491 16.8759 16.5791L16.8759 12.5091C16.8759 12.3491 16.7459 12.2191 16.5859 12.2191L2.03592 12.2191C1.87592 12.2191 1.74592 12.3491 1.74592 12.5091Z M16.58 8.15C17.71 8.14 18.62 7.23 18.62 6.11L18.62 2.04C18.62 0.91 17.71 0 16.58 0L2.04 0C0.91 0 2.22045e-16 0.91 2.22045e-16 2.04L2.22045e-16 6.11C2.22045e-16 7.23 0.91 8.14 2.04 8.15L16.58 8.15Z M1.74594 6.10497C1.74594 6.27497 1.87594 6.40497 2.03594 6.40497L16.5859 6.40497C16.7459 6.40497 16.8759 6.27497 16.8759 6.10497L16.8759 2.03497C16.8759 1.87497 16.7459 1.74497 16.5859 1.74497L2.03594 1.74497C1.87594 1.74497 1.74594 1.87497 1.74594 2.03497L1.74594 6.10497Z "})))))),u=a=>e.createElement("svg",{xmlns:"http://www.w3.org/2000/svg",xmlnsXlink:"http://www.w3.org/1999/xlink",width:21,height:21,viewBox:"0 0 21 21",fill:"none",...a},e.createElement("defs",null,e.createElement("rect",{id:"path_0",x:0,y:0,width:21,height:21}),e.createElement("rect",{id:"path_1",x:0,y:0,width:24,height:24})),e.createElement("g",{opacity:1,transform:"translate(0 0)  rotate(0 10.5 10.5)"},e.createElement("mask",{id:"bg-mask-0",fill:"white"},e.createElement("use",{xlinkHref:"#path_0"})),e.createElement("g",{mask:"url(#bg-mask-0)"},e.createElement("g",{opacity:1,transform:"translate(-1 -1)  rotate(0 12 12)"},e.createElement("mask",{id:"bg-mask-1",fill:"white"},e.createElement("use",{xlinkHref:"#path_1"})),e.createElement("g",{mask:"url(#bg-mask-1)"},e.createElement("path",{id:"\\u8DEF\\u5F84 1",fillRule:"evenodd",style:{fill:"#4A4A4A"},transform:"translate(9 9)  rotate(0 2.9999999999999987 3)",opacity:1,d:"M0,3C0,4.64 1.36,6 3,6C4.64,6 6,4.64 6,3C6,1.36 4.64,0 3,0C1.35,0.01 0.01,1.35 0,3Z "}),e.createElement("path",{id:"\\u5206\\u7EC4 1",fillRule:"evenodd",style:{fill:"#4A4A4A"},transform:"translate(2.0002652231768216 4.999999992187178)  rotate(0 9.999734776823237 7.000000007812499)",opacity:1,d:"M0.05 6.68C-0.02 6.89 -0.02 7.11 0.05 7.32C0.07 7.38 2.37 14 10 14C17.63 14 19.93 7.38 19.95 7.32C20.02 7.11 20.02 6.89 19.95 6.68C19.93 6.62 17.63 0 10 0C2.37 0 0.07 6.62 0.05 6.68Z M17.9237 7C17.4237 5.85 15.3537 2 10.0037 2C4.65373 2 2.57373 5.84 2.07373 7C2.57373 8.15 4.65373 12 10.0037 12C15.3437 12 17.4237 8.16 17.9237 7Z "})))))),y=r.div`
    --adm-color-background: transparent;
    background: rgba(249, 255, 247, 1);
    --body-wrapper-background: rgba(249, 255, 247, 1);
    height:100%;
    min-height: 100vh;
    left:0;
    top:0;
    width:100%;
`,v=r.h3`
    font-size:24px;
    padding: 15px 0;
    text-align:center;
    margin-top: 8px;
`,b=r.div`
    svg{
        path{
            fill: #4A4A4A!important;
        }
    }
`,S=r.div`
     margin:0 32px;
     .adm-list-body{
        --border-bottom: 0px;
     }
`,A=r.div`
    --adm-color-box:rgba(232, 232, 232, 0.5);
    padding: 10px 13px;
    
    .adm-search-bar-input-box{
        --border-radius: 20px;
        flex-direction: row-reverse;
        padding-right: var(--padding-left);
    }
`,_=r.span`
    font-size:20px;
    margin-right:5px;
`;r.a`
    display:flex;
`;r.span`
    font-size:20px;
    margin-right:5px;
    display:inline-block;
    width:24px;
    height:24px;
    svg{
        width:24px;
        height:24px;
    }
`;const i=r(_)`
    svg{
        width:18.5px;
        height:18.5px;
        margin-top:8px;
    }
`,I=()=>{const a=x(),d=w(),[m,g]=e.useState(),p=()=>{};return t(y,{children:t(o,{children:s(o.Body,{children:[t(c,{left:t(b,{onClick:()=>{a(-1)},children:c.Back})}),s(S,{children:[t(v,{children:"Global Settings"}),t(A,{children:t(k,{placeholder:"Search Settings",style:{"--height":"24px"},onSearch:p,value:m,onChange:C=>{g(C)}})}),s(l,{style:{"--border-top":"0px"},children:[t(l.Item,{prefix:t(i,{children:t(E,{})}),onClick:()=>{f(),a("/onboarding/lock_screen")},arrow:t(n,{}),children:"Lock Wallet"}),t(l.Item,{prefix:t(i,{children:t(L,{})}),onClick:d,arrow:t(n,{}),children:"Extended View"}),t(l.Item,{prefix:t(i,{children:t(u,{})}),onClick:()=>{a("/settings/seed_recovery")},arrow:t(n,{}),children:"Show Phrase"}),t(l.Item,{prefix:t(i,{children:t(h,{})}),onClick:()=>{a("/settings/block_explorer")},arrow:t(n,{}),children:"Block Explorer"}),t(l.Item,{prefix:t(i,{children:t(h,{})}),onClick:()=>{a("/settings/reset")},arrow:t(n,{}),children:"Reset Or Recover"})]})]})]})})})};export{I as default};
//# sourceMappingURL=index-c79c98f4.js.map
