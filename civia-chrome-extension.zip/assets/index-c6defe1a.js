import{X as e,a4 as s,n as t,W as i,o,N as c,aZ as p,q as a,a0 as g}from"./index.html-a1016547.js";import{F as h}from"./index-785eecfa.js";import{aV as n}from"./index-23cb1aae.js";const m=r=>n.createElement("svg",{xmlns:"http://www.w3.org/2000/svg",xmlnsXlink:"http://www.w3.org/1999/xlink",width:29,height:32,viewBox:"0 0 29 32",fill:"none",...r},n.createElement("path",{id:"\\u8DEF\\u5F84 1",fillRule:"evenodd",style:{fill:"#FFFFFF"},transform:"translate(-0.0009765625 0)  rotate(0 14.025849065102204 15.705000000000002)",opacity:1,d:"M27.77,23.13C26.06,19.35 22.64,16.65 18.32,15.57C20.66,14.04 22.19,11.34 22.19,8.46C22.19,3.78 18.41,0 13.73,0C9.05,0 5.27,3.78 5.27,8.46C5.27,11.43 6.89,14.13 9.32,15.66C5.18,16.83 1.76,19.62 0.23,23.31C-0.4,24.84 0.32,27 1.76,27.9C5.36,30.24 9.59,31.41 13.91,31.41C18.41,31.41 22.73,30.06 26.33,27.81C27.77,26.82 28.49,24.66 27.77,23.13Z "})),C=r=>n.createElement("svg",{xmlns:"http://www.w3.org/2000/svg",xmlnsXlink:"http://www.w3.org/1999/xlink",width:20,height:34,viewBox:"0 0 20 34",fill:"none",...r},n.createElement("g",{opacity:1,transform:"translate(0 0)  rotate(0 9.805184364318848 16.62434396147728)"},n.createElement("path",{id:"\\u8DEF\\u5F84 1",fillRule:"evenodd",style:{fill:"#4CD130"},transform:"translate(7 16.24868792295456)  rotate(0 2 8.5)",opacity:1,d:"M0,17L4,17L4,0L0,0L0,17Z "}),n.createElement("path",{id:"\\u5206\\u7EC4 1",fillRule:"evenodd",style:{fill:"#4CD130"},transform:"translate(0 0)  rotate(0 9.805184364318848 16.02539825439453)",opacity:1,d:"M10.4874 26.2636L14.3674 26.2636L14.3674 21.8136L10.4874 21.8136L10.4874 26.2636Z M10.4874 32.0508L15.5074 32.0508L15.5074 27.6008L10.4874 27.6008L10.4874 32.0508Z M16.7603 16.3603C18.6003 14.5603 19.6203 12.1203 19.6103 9.57029C19.6203 7.03029 18.6003 4.58029 16.7603 2.78029C14.9103 0.980294 12.4103 -0.0197057 9.80029 0.000294332C7.20029 -0.0197057 4.69029 0.980294 2.85029 2.78029C1.01029 4.58029 -0.0197138 7.03029 0.000286185 9.57029C-0.0197138 12.1203 1.01029 14.5603 2.85029 16.3603C4.69029 18.1603 7.20029 19.1603 9.80029 19.1403C12.4103 19.1603 14.9103 18.1603 16.7603 16.3603Z M6.06922 5.92138C5.07922 6.89138 4.53922 8.21138 4.55922 9.57138C4.53922 10.9414 5.07922 12.2514 6.06922 13.2214C7.05922 14.1814 8.40922 14.7114 9.79922 14.6914C11.1992 14.7114 12.5492 14.1814 13.5392 13.2214C14.5292 12.2514 15.0692 10.9414 15.0492 9.57138C15.0692 8.21138 14.5292 6.89138 13.5392 5.92138C12.5492 4.96138 11.1992 4.43138 9.79922 4.45138C8.40922 4.43138 7.05922 4.96138 6.06922 5.92138Z "}))),x=e.div`
    background: rgba(249, 255, 247, 1);
    --body-wrapper-background: rgba(249, 255, 247, 1);
    height:100%;
    left:0;
    top:0;
    width:100%;
    min-height:100vh;
    border:1px solid transparent;
    
`,u=e.div`
    width: 215px;
    height:30px;
    margin:30px auto 0;
    --adm-button-background-color: transparent;
`,w=e.div`
    padding: 20px 0 10px;
    text-align:center;
    svg{
        width:56px;
        height:56px;
        display:inline-block;
        margin:auto;
        path{
            fill: var(--color-primary)!important;
        }
    }
`,y=e(a)`
    --border-top:0;
    --border-bottom:0;
    --border-inner:0;
    --adm-color-background: transparent;
    .adm-list-item-content-main{
        padding:25px 0;
    }
`,l=e.span`
    display: inline-block;
    margin-right:14px;
    height:26px;
    svg{
        width:26px;
        height:26px;
        text-align:center;
    }
`,d=e(g)`
    width:242px;
    height:54px;
    line-height:38px;
    border-radius: 20px;
    font-size: 16px;
    margin:auto;
    >span{
        display: flex;
        align-items: center;
        margin: auto;
        justify-content: center;
    }
`,v=e.h3`
    font-size:24px;
    padding: 15px 0;
    text-align:center;
    margin-top: 8px;
`,L=()=>{const r=s();return t(x,{children:t(i,{children:o(i.Body,{children:[t(u,{children:t(c,{disabled:!0})}),t(w,{children:t(p,{})}),t(v,{children:"Welcome to Civia"}),o(y,{children:[t(a.Item,{children:o(d,{block:!0,onClick:()=>{r("/onboarding/inviter")},color:"primary",children:[t(l,{children:t(m,{})}),"Create Account"]})}),t(a.Item,{children:o(d,{block:!0,onClick:()=>{r("/onboarding/restore_seed")},children:[t(l,{children:t(C,{})}),"Import Account"]})})]}),t(h,{content:"Need help? Contact Civia support",style:{"--background-color":"transparent","--adm-color-light":"#000",margin:"40px auto 0"}})]})})})};export{L as default};
//# sourceMappingURL=index-c6defe1a.js.map
