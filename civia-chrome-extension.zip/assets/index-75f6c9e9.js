import{aV as s,aY as x,L as b}from"./index-23cb1aae.js";import{X as c,a5 as _,a4 as k,a7 as I,bg as N,n as e,aH as v,W as u,o as p,j as f,q as g}from"./index.html-a1016547.js";import{u as A}from"./useNfts-8eacf436.js";import C from"./index-cb471617.js";import B from"./index-8d245b5d.js";import"./aspect.service-1342d8b4.js";import"./CloseCircleOutline-d09d2799.js";const E=c.div`
    background-size: contain;
    background-position: center;
    background-repeat: no-repeat;
`,w=()=>{const[t,i]=s.useState(),[o,d]=s.useState({}),l=s.useCallback(({style:n={},src:r=null,...m})=>x.createElement(E,{style:{...o,backgroundImage:`url(${r||t}), url(${t})`,...n},...m}),[o,t]);return s.useEffect(()=>{if(t){const[,n,r]=t.match(/(\w+)x(\w+)$/)||[1,1,1];d({paddingTop:`${parseFloat(r)*100/parseFloat(n)}%`})}},[t]),{src:t,info:o,NftImage:l,setSrc:i}},$=c.div`
    min-height:320px;
`,L=c.h3`
    font-size:24px;
    padding: 15px 0;
    text-align:center;
    margin-top: 8px;
`,W=c.div`
    svg{
        path{
            fill: #4A4A4A!important;
        }
    }
`,j=c(g)`
    --border-inner: 0;
    --border-bottom: 0;
    --border-top: 0;
`,q=c.div`
    margin: 20px auto;
    width: ${({type:t})=>t==="detail"?"80%":"100px"}!important;
    background-color: #fefefe;
`,T=()=>{const t=_(),i=k(),{id:o}=I(),d=N(),{NftImage:l,setSrc:n}=w(),{type:r,tokenId:m}=d.state||{},{nfts:h=[]}=A(t),[a]=s.useState(()=>h.filter(Boolean).find(({contract_address:y,token_id:S})=>o&&b(y,o)&&S===m));return s.useEffect(()=>{n(a.image_small_url_copy)},[a.image_small_url_copy,n]),a?e(u,{children:p(u.Body,{children:[e(f,{left:e(W,{onClick:()=>{i(-1)},children:f.Back})}),p($,{children:[e(L,{children:a.name||a.contract.name_custom||a.contract.name||"Untitled"}),p(j,{children:[e(g.Item,{children:e(q,{type:r,children:e(l,{src:a.image_url_copy})})}),r==="detail"?e(C,{contractAddress:o,nftDetail:a}):e(B,{contractAddress:o,nftDetail:a})]})]})]})}):e(v,{})};export{T as default};
//# sourceMappingURL=index-75f6c9e9.js.map
