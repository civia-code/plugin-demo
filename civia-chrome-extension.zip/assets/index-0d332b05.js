import{aV as h}from"./index-23cb1aae.js";import{n as e,a9 as f,X as c,a4 as u,a5 as g,aa as x,aM as b,o,W as d,A as y,c as v,i as n,aH as w,aC as k,_ as C,ad as A,a0 as _}from"./index.html-a1016547.js";import{u as T}from"./useCollections-cb9cca63.js";import"./aspect.service-1342d8b4.js";import"./useNfts-8eacf436.js";const B=c.div`
    min-height:320px;
    padding: 20px 10px;
`,N=c(C)`
    padding: 0 32px;
`,S=c(A)`
    border-radius: 0;
    border-bottom: 1px solid #395C3E;
    &:hover{
        cursor: pointer;
    }
    .adm-card-body{
        padding: 0;
    }

    .adm-image{
        width: 130px;
        height: 130px;
        border-radius:10px;
        overflow:hidden;
    }

    .info{
        font-size: 14px;
        font-weight: 400;
        line-height:19px;
        overflow: hidden;
        text-overflow: ellipsis;
        margin: 8px 0;
        display: flex;
        justify-content: space-between;
        span:nth-child(1){
            width: 100px;
            display: inline-block;
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
        }
    }
`;c(_)`
    padding: 0 5px;
    margin: 0 3px;
    color: var(--adm-color-primary);
    font-size:12px;
`;const j=()=>{const i=u(),a=g();return a?e(E,{account:a}):(i("/account/list"),null)},E=({account:i})=>{const a=u(),[l,m]=h.useState([]),s=T(i);return x("tokens"),console.log("collectibles -----",s),h.useEffect(()=>{const t=s&&s.length?s[0]?.nfts:[];for(const r of t)b.get(`${r.token_uri}${r.token_id}`).then(p=>{console.log("res -----",p),r.image_uri=p.data.image});console.log("list -----",t),m(t)},[]),o(d,{children:[e(d.Head,{children:o(y,{children:[e(v,{}),o(n,{onChange:t=>{switch(t){case"1":a("/account/tokens");break;case"2":break;case"3":a("/account/sbts");break}},defaultActiveKey:"2",children:[e(n.Tab,{title:"Tokens"},"1"),e(n.Tab,{title:"NFTs"},"2"),e(n.Tab,{title:"SBTs"},"3")]})]})}),e(d.Body,{children:e(B,{children:l.length===0?e(w,{}):e(N,{columns:2,gap:16,children:l.map(t=>o(S,{onClick:()=>{a("/nfts/list",{state:{name:t.name,contractAddress:t?.contract?.contract_address}})},children:[e(k,{src:t.image_uri||"https://pic3.zhimg.com/v2-d023feeb25332d8d120c182525426876_1440w.jpg?source=172ae18b"}),o("div",{className:"info",children:[e("span",{children:t.contract?.name}),o("span",{children:["#",t.token_id]})]})]},t?.contract?.contract_address))})})})]})},G=()=>e(f,{children:e(j,{})});export{G as default};
//# sourceMappingURL=index-0d332b05.js.map
