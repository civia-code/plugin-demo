import{x as X,bG as J,bH as K,r as p,b0 as Q,D as Y,aV as u,bI as Z,be as ee,bi as te}from"./index-23cb1aae.js";import{bj as D,bD as ae,bE as se,X as b,q as ne,a4 as oe,a5 as re,aB as ie,aG as de,b8 as le,bF as ce,o as d,p as N,n as e,b7 as me,a0 as T,h as ue,bi as R,bC as pe,aC as he,bh as be,a3 as ge,bk as fe}from"./index.html-a1016547.js";import{C as xe}from"./CloseCircleOutline-d09d2799.js";const h=(i,t=18)=>K(i.replace(",","."),p.toBN(t).toNumber());X().trim().required("Amount is required").test((i,t)=>{if(!i)return t.createError({message:"Amount is required"});try{const s=h(i);if(s.isNegative())return t.createError({message:"Amount must be positive"});if(s.eq(0))return t.createError({message:"Amount can not be zero"});if(s.gt(J))return t.createError({message:"Amount is too big"})}catch{return t.createError({message:"Amount should be a number"})}return!0});const{compileCalldata:ve,estimatedFeeToMaxFee:ye}=Y,Ae=(i,t,s)=>{if(!s||!t||!i)throw new Error("Account, TokenAddress and Balance are required");const y={contractAddress:i,entrypoint:"transfer",calldata:ve({recipient:s.address,amount:D(t)})},{data:n,error:l,isValidating:c}=Q(["maxEthTransferEstimate",Math.floor(Date.now()/6e4),s.networkId],async()=>(await ae(s.networkId))?.address!==i?{amount:"0",suggestedMaxFee:"0"}:se(y),{suspense:!1,refreshInterval:15e3,shouldRetryOnError:!1});if(l)return{maxFee:void 0,error:l,loading:!1};if(n){const{suggestedMaxFee:m,maxADFee:o}=n,A=s.needsDeploy&&o?p.toHex(p.toBN(o).add(p.toBN(m))):m,r=ye(A,.2);return{maxFee:p.toHex(r),error:void 0,loading:!1}}return{maxFee:void 0,error:void 0,loading:c}},k=b(ne.Item)`
    position: relative;
    padding-bottom:10px;
    .error{
        color:red;
        position: absolute;
        bottom:3px;
        left:16px;
        line-height:15px;
        visibility: hidden;
        &.on{
            visibility: visible;
            font-size:12px;
        }
    }
`,I=b.div`
    width:100%;
    position:relative;
    display:flex;
    align-items: center;
    >div{
        vertical-align: middle;
       

        &:nth-of-type(1){
            width:100%;
        }
        &:nth-of-type(2){
            
        }
    }
`,Fe=b.div`
    text-align: center;
`,ke=b.div`
    display: flex;

    Button{
        border-radius: 25px;
        min-width:25px;
        height:100%;
        color:#fff;
        padding:0 5px;
        margin:0 5px;
    }
`,Ie=b(ge)`
    
`,Me=({tokenAddress:i,currentToken:t})=>{const s=oe(),{sendTransaction:y}=fe(),[n,l]=u.useReducer((a,{type:x,inputVal:v})=>v.match(/^\d+\.?\d{0,18}/g)?.join("")||"",""),[c,m]=u.useState(),o=re(),A=o&&Z(o.networkId),[r,q]=u.useState(),{accountNames:w}=ie(),F=u.useMemo(()=>r?"name"in r?r.name:de(r,w):void 0,[w,r]),{address:z,name:U,symbol:we,balance:V,decimals:g,image:j}=le(t),{maxFee:f,error:Se,loading:H}=Ae(t?.address,t?.balance,o);console.log(f);const S=h(n||"0",g),L=t.balance||h("0",g),B=S.gt(t.balance?.toString()??0)||A?.address===t.address&&(n===V||S.add(f?.toString()??0).gt(L)),G=!n||B||!(c||r),O=u.useCallback((a,x)=>{const v=a.decimals??18,$=ce(a.balance,v);if(a.balance&&x){const C=a.balance,E=o?.networkId==="localhost"?C.sub(x).sub(1e14):C.sub(x),P=ee(E,v),M=E.lte(0)?$:P;console.log(M),l({inputVal:M})}},[o?.networkId]),W=async()=>{await y({to:z,method:"transfer",calldata:{recipient:c||r?.address,amount:D(h(n,g))}}),s("/dapp")},_=a=>{f&&a&&O(a,f)};return d(N,{children:[e(Fe,{children:me(t)}),d(Ie,{layout:"horizontal",onFinish:W,style:{"--border-bottom":"0px","--border-top":"0px"},footer:e(T,{block:!0,type:"submit",color:"primary",disabled:G,style:{borderRadius:"20px",padding:"10px 12px"},children:"Next"}),children:[d(k,{prefix:e("div",{style:{lineHeight:"100%"},children:e(ue,{name:U,url:j,size:24})}),children:[d(I,{children:[e("div",{children:e(R,{value:n,onChange:a=>{l({inputVal:a})},placeholder:"Amount"})}),n?null:e("div",{children:d(ke,{children:[e("div",{children:t.symbol}),e("div",{children:e(T,{onClick:()=>{_(t)},color:"primary",children:H?e(pe,{style:{fontSize:16},color:"white"}):e(N,{children:"Max"})})})]})})]}),e("div",{className:`error ${n&&B?"on":""}`,children:"Insufficient balance"})]}),r&&F?e(k,{prefix:e(he,{src:be({accountName:F,accountAddress:o.address,networkId:o.networkId,backgroundColor:o.hidden?"333332":void 0}),style:{borderRadius:12},fit:"cover",width:24,height:24}),children:d(I,{children:[d("div",{children:[e("div",{children:F}),e("div",{style:{fontSize:12},children:te(r.address)})]}),e("div",{onClick:()=>{q(void 0)},children:e(xe,{})})]})}):e(k,{children:e(I,{children:e("div",{children:e(R,{value:c,onChange:a=>{m(a)},placeholder:"Recipient's address"})})})})]})]})};export{Me as default};
//# sourceMappingURL=index-a23db5bc.js.map
