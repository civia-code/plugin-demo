import{aV as m,b5 as p}from"./index-23cb1aae.js";import{n as e,a9 as g,X as c,q as u,a4 as h,a5 as f,b5 as x,aa as y,b6 as d,b7 as T,o as s,W as l,A as k,c as v,i,h as S,b8 as w,ac as A}from"./index.html-a1016547.js";const B=c.div`
    min-height:320px;
    padding: 20px 13px;
`,C=c(u)`
    --border-top: 0;
    --border-bottom: 0;
    --border-inner: 0;
    --font-size: var(--adm-font-size-8);
    .adm-list-item-content{
        padding: 10px var(--padding-right) 10px 0;
    }
`,N=c(u.Item)`
    background-color: rgba(240, 240, 240, 1);
    margin-bottom: 8px;
    border-radius:10px;
`,I=c.div`
    color:var(--adm-color-text);
    margin-right: 16px;
    font-size: 18px;
    >div:nth-of-type(1){
        max-width: 160px;
        word-break: break-all;
        overflow: hidden;
        text-align: right;
    }

    >div:nth-of-type(2){
        font-size:12px;
        text-align:right;
    }
`,z=()=>{const n=h(),a=f();return m.useEffect(()=>{a||n("/account/list")},[a,n]),a?e(V,{account:a}):null},L=({token:n,children:a})=>{const r=x(n);return a(r)},V=({account:n})=>{const a=h();y("tokens"),d(n);const{tokenDetails:r}=d(n);for(const t of r){t.balanceStr=T(t);const o=t.balanceStr.split(" ");!isNaN(Number(o[0]))&&Number(o[0])<1e-5&&Number(o[0])!==0&&(t.balanceStr=`< 0.00001 ${o[1]}`)}const b=t=>{console.log("item ---",t);const o=n&&p(n);window.localStorage.setItem(`@"${o}","myToken"`,JSON.stringify(t)),a(`/tokens/${t.address}`,{state:{type:"detail"}})};return s(l,{children:[e(l.Head,{children:s(k,{children:[e(v,{}),s(i,{onChange:t=>{switch(t){case"1":break;case"2":a("/account/nfts");break;case"3":a("/account/sbts");break}},children:[e(i.Tab,{title:"Tokens"},"1"),e(i.Tab,{title:"NFTs"},"2"),e(i.Tab,{title:"SBTs"},"3")]})]})}),e(l.Body,{children:e(B,{children:e(C,{children:r.map(t=>e(L,{children:o=>s(N,{prefix:e("div",{style:{lineHeight:"100%"},children:e(S,{...w(t),url:t.image,size:48})}),extra:e(I,{children:e("div",{children:t?.balanceStr})}),onClick:()=>b(t),arrow:e(A,{}),children:[e("p",{children:t.name}),e("p",{style:{fontSize:12,color:"#999"},children:t.symbol})]})},t.address))})})})]})},H=()=>e(g,{children:e(z,{})});export{L as TokenListItemContainer,H as default};
//# sourceMappingURL=index-7e31fc58.js.map
