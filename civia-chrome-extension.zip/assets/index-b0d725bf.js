import{bh as H,aV as n}from"./index-23cb1aae.js";import{X as o,q as N,a4 as q,a5 as F,aO as P,aY as $,n as t,W as k,o as b,j as C,aZ as D,ad as L,m as A,a0 as T,a_ as K,a$ as X,b0 as Y,as as y,b1 as Z,b2 as Q,b3 as ee,b4 as te}from"./index.html-a1016547.js";import{F as se}from"./index-785eecfa.js";const ae=o.div`
    background: rgba(249, 255, 247, 1);
    --body-wrapper-background: rgba(249, 255, 247, 1);
    height:100%;
    left:0;
    top:0;
    width:100%;
    min-height:100vh;
    border:1px solid transparent;
`,ne=o.div`
    svg{
        path{
            fill: #4A4A4A!important;
        }
    }
`,oe=o.div`
    min-height:100vh;
`,re=o.div`
    padding: 20px 0 10px;
    text-align:center;
    svg{
        width:56px;
        height:56px;
        display:inline-block;
        margin:auto;
        path{
            fill: var(--color-primary)!important;
        }
    }
`,R=o(N)`
    --adm-color-background: transparent;
    margin:20px 10px;
`;o(N.Item)`
    text-align: right;
    .adm-list-item-content{
        border-top:0;
    }
`;o.div`
    display: flex;
    align-items: center;
`;const ie=o.h3`
    font-size:24px;
    padding: 15px 0;
    text-align:center;
    margin-top: 8px;
`,O=o(T)`
    height:40px;
    border-radius:20px;
    width:242px;
    margin:4px auto;
    line-height: unset;
`,ce=o.div`
    padding: 10px 0;
`;o(T)`
    width: 50px;
    height: 36px;
    svg {
        width: 20px;
        height: 20px;
        /* position: relative;
        top: 2px; */
    }
`;const pe=()=>{const v=q(),p=F(),r=H(p?.address),f=`${r},guardians`,[u,x]=n.useState(JSON.parse(window.localStorage.getItem(f))||[]),[B,m]=n.useState(!1);n.useState(""),n.useState(""),n.useState(!1),n.useState(!1);const[l,I]=n.useState([]),[d,le]=n.useState(u),[w,J]=n.useState([]),[M,V]=n.useState(""),[E,G]=n.useState([]),[S,...U]=d,g=U.map(e=>e.address);n.useEffect(()=>{p&&P(p?.address,1,200).then(e=>{if(e&&e?.length){const a=[];for(let s=0;s<e[0].length;s++)a.push({address:e[0][s],accountId:e[1][s],nickname:e[2][s],isPending:!1});console.log("list -----",a),J(a)}})},[]);const z=async()=>{p&&(m(!0),K({}).then(e=>e?X({guardians:g,oldOwnerAddress:S.address,newOwner:e[0]}).then(a=>{if(a){const s={oldOwnerAddress:S.address,type:98,tx:a};for(const h of g)Y({account:r,from:r,to:h,title:"Recovery",content:JSON.stringify(s)}).catch(i=>{y.show({content:JSON.stringify(i)})});window.localStorage.setItem(f,JSON.stringify(d)||""),x(d)}return a||"Unknow Error"}):"Unknow Error").then(e=>{console.log(["tx",e]),y.show({content:e})}).finally(()=>{m(!1)}))},W=async()=>{try{m(!0);const e=l.filter(s=>s.from===g[0])[0],a=l.filter(s=>s.from===g[1])[0];if(e&&a){const s=await Z(S.address,[e.content.res,a.content.res]);y.show({content:JSON.stringify(s)}),l.forEach(h=>{Q({account:r,message_id:h.message_id})}),window.localStorage.removeItem(f),x([]),v(-1)}}catch(e){y.show({content:JSON.stringify(e)})}finally{m(!1)}},_=e=>{V(e)},j=e=>{G(e)};return $(()=>{r&&u.length>2&&(ee({account:r}),te({account:r,limit:10,page_no:1}).then(e=>{const a=e.result.messages,s=[],h=a.reduce((i,c)=>(s.includes(c.from)||g.includes(c.from)&&(s.push(c.from),i.push({...c,content:JSON.parse(c.content),timestamp:new Date(c.timestamp).getTime()})),i),[]).filter(i=>i.content.msgType===99);I(h)}))},1e4),u.length>2,console.log(l),t(ae,{children:t(k,{loading:B,children:b(k.Body,{children:[t(C,{left:t(ne,{onClick:()=>{v(-1)},children:C.Back})}),t(re,{children:t(D,{})}),t(ie,{children:"Social Recovery"}),b(oe,{children:[t(R,{mode:"card",children:t(L,{title:"To Recovery",style:{maxHeight:220,overflow:"scroll"},children:t(A,{gridType:"listRadio",list:w,checkValue:M,handleCheckChange:_})})}),t(R,{mode:"card",children:t(L,{title:"Guardians",style:{maxHeight:220,overflow:"scroll"},children:t(A,{gridType:"listCheck",list:w,checkValue:E,handleCheckChange:j})})}),t(ce,{children:u.length<=0?t(O,{block:!0,type:"submit",color:"primary",size:"large",loadingText:"creating",onClick:z,disabled:d.length<3||!d[0],children:"Start recovery"}):t(O,{block:!0,type:"submit",color:"primary",size:"large",loadingText:"creating",onClick:W,disabled:l.length<2,children:"Recovery"})})]}),t(se,{content:"Need help? Contact Civia support",style:{"--background-color":"transparent","--adm-color-light":"#000",margin:"0px auto 0"}})]})})})};export{pe as default};
//# sourceMappingURL=index-b0d725bf.js.map
