import{aV as s}from"./index-23cb1aae.js";import{n as t,a9 as r,X as e,a4 as d,a5 as a,aa as p,W as c,o as n,q as u}from"./index.html-a1016547.js";import{PendingTransactionsCom as m,AccountActivityCom as l}from"./index-374d07b5.js";import"./transformTransaction-662c19cf.js";import"./aspect.service-1342d8b4.js";import"./is-b46cff69.js";import"./index-9d5a35b1.js";import"./useDisplayTokenAmountAndCurrencyValue-c18faa62.js";const x=e.div`
    min-height:320px;
    padding: 20px 10px;
`,y=e.h3`
    font-size:24px;
    padding: 15px 0;
    text-align:center;
    margin-top: 8px;
`,f=()=>{const o=d(),i=a();return s.useEffect(()=>{i||o("/account/list")},[i,o]),i?t(g,{account:i}):null},g=()=>{const o=a();return p("activity"),t(c,{children:n(c.Body,{children:[t(y,{children:"Activities"}),t(x,{children:n(u,{mode:"card",children:[t(m,{account:o}),t(l,{account:o})]})})]})})},E=()=>t(r,{children:t(f,{})});export{E as default};
//# sourceMappingURL=index-437f492a.js.map
