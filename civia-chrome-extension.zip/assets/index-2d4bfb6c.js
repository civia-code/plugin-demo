import{X as n,q as a,a4 as o,o as t,n as e,al as d,bl as i,a0 as l}from"./index.html-a1016547.js";import{S as h}from"./index-14b29165.js";import{F as s}from"./index-785eecfa.js";import"./index-23cb1aae.js";const p=n.div`
    min-height:320px;
    margin: 10px 0;
`,x=n(a)`
    margin:20px 10px;
`,r=n(a.Item)`
    text-align: right;
`,m=n(l)`
    margin: 20px auto;
    display: block;
`,S=()=>{const c=o();return t("div",{children:[e(d,{back:"back",onBack:()=>{window.history.go(-1)},children:"Create Account"}),t(p,{children:[t(x,{mode:"card",header:"Inviter",children:[e(r,{children:e(h,{placeholder:"请输入内容",showCancelButton:!0})}),e(r,{prefix:e(i,{children:"Jake"}),children:"#99865233"}),e(r,{prefix:e(i,{children:"Jede"}),children:"#8769475"}),e(r,{prefix:e(i,{children:"Jeny"}),children:"#50897342"}),e(r,{prefix:e(i,{children:"John"}),children:"#3093826255"}),e(r,{prefix:e(i,{children:"Jake"}),children:"#987634"}),e(r,{prefix:e(i,{children:"Joye"}),children:"#99865233"}),e(r,{prefix:e(i,{children:"July"}),children:"#78745673"})]}),e(m,{onClick:()=>{c("/onboarding/password")},children:"Done"})]}),e(s,{content:"@Civia 2022"})]})};export{S as default};
//# sourceMappingURL=index-2d4bfb6c.js.map
