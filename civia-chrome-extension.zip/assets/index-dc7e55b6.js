import{aV as i,bd as l}from"./index-23cb1aae.js";import{af as B,ae as N,o as u,ai as b,n as e,at as I,X as s,q as S,a5 as P,a4 as w,au as $,av as k,r as L,Y as G,aw as T,ax as z,W as y,j as A,ad as v,ay as p,az as W}from"./index.html-a1016547.js";const o="adm-progress-bar",_={percent:0,rounded:!0,text:!1},j=a=>{const r=B(_,a),t={width:`${r.percent}%`},n=function(){return r.text===!0?`${r.percent}%`:typeof r.text=="function"?r.text(r.percent):r.text}();return N(r,u("div",{className:b(o,r.rounded&&`${o}-rounded`),children:[e("div",{className:`${o}-trail`,children:e("div",{className:`${o}-fill`,style:t})}),I(n)&&e("div",{className:`${o}-text`,children:n})]}))},D=j,F=s.div`
    --adm-color-background: transparent;
    background: rgba(249, 255, 247, 1);
    --body-wrapper-background: rgba(249, 255, 247, 1);
    height:100%;
    min-height: 100vh;
    left:0;
    top:0;
    width:100%;
`,M=s.h3`
    font-size:24px;
    padding: 15px 0;
    text-align:center;
    margin-top: 8px;
`,O=s.div`
    svg{
        path{
            fill: #4A4A4A!important;
        }
    }
`,R=s.div`
     margin:0 32px;
     .adm-list-body{
        --border-bottom: 0px;
     }
`,q=s(S)`
    svg{
        vertical-align: -0.25em!important;
    }
`,c=s(S.Item)`

`,H=s(W)`
    --adm-color-weak: var(--adm-color-primary);
    margin: 32px auto;
`,K=s.div`
    width: 50%;
    margin: auto;
`,Y=()=>{const a=P();return a?e(U,{account:a}):null},U=({account:a})=>{const r=w(),[t,n]=i.useState(1);$(a);const{isBalanceEnougth:h}=k(a),{transactions:x,pendingTransactions:g}=L(a),{accountInfoData:C={}}=G(a,a.address),{idInfo:m="0"}=C;return console.log([t,h,g.length,m]),i.useEffect(()=>{if(t===4){const{address:d}=l.get("inviteInfo")||{};T(1,[d],a).then(f=>{const E=`${a?.address},guardians`;l.set(E,[{addressResult:d}])})}},[t,a]),i.useEffect(()=>{l.set(`${a.address},initializing`,1)},[]),i.useEffect(()=>{t===1&&h&&n(Math.max(t,2))},[t,h]),i.useEffect(()=>{t===2&&g.length&&n(Math.max(t,3))},[t,g.length]),i.useEffect(()=>{m.length>3&&n(Math.max(4))},[m]),i.useEffect(()=>{const d=x.some(f=>["ACCEPTED_ON_L1","ACCEPTED_ON_L2"].includes(f.status)&&f.meta?.title==="Add guardians");t===4&&d&&n(5)},[t,x]),t>=5?(l.delete(`${a.address},initializing`),e(z,{to:"/account/home"})):e(F,{children:e(y,{children:u(y.Body,{children:[e(A,{left:e(O,{onClick:()=>{r(-1)},children:A.Back})}),u(R,{children:[e(M,{children:"Create Account"}),e(v,{children:u(q,{children:[e(c,{prefix:e(p,{color:t>=1?"var(--adm-color-primary)":"transparent"}),children:"Create account"}),e(c,{prefix:e(p,{color:t>=2?"var(--adm-color-primary)":"transparent"}),children:"Receive initial gas"}),e(c,{prefix:e(p,{color:t>=3?"var(--adm-color-primary)":"transparent"}),children:"Initialize account"}),e(c,{prefix:e(p,{color:t>=5?"var(--adm-color-primary)":"transparent"}),children:"Follow inviter and set as guardian"}),e(v,{children:e(c,{children:e(K,{children:e(D,{percent:t/5*100})})})})]})}),e(v,{children:e(H,{})})]})]})})})};export{Y as default};
//# sourceMappingURL=index-dc7e55b6.js.map
