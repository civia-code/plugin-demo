import{n as p,by as m,aV as g,bz as C,bA as x}from"./index-23cb1aae.js";import{n as e,o as l,X as r,a3 as y,a4 as f,W as a,j as c,q as s,a0 as d}from"./index.html-a1016547.js";function v(n){return n&&n.length?p(n):[]}function w(n){return e("svg",{...Object.assign({width:"1em",height:"1em",viewBox:"0 0 48 48",xmlns:"http://www.w3.org/2000/svg",xmlnsXlink:"http://www.w3.org/1999/xlink"},n,{style:Object.assign({verticalAlign:"-0.125em"},n.style),className:["antd-mobile-icon",n.className].filter(Boolean).join(" ")}),children:e("g",{id:"MinusCircleOutline-MinusCircleOutline",stroke:"none",strokeWidth:1,fill:"none",fillRule:"evenodd",children:l("g",{id:"MinusCircleOutline-编组",children:[e("rect",{id:"MinusCircleOutline-矩形",fill:"#FFFFFF",opacity:0,x:0,y:0,width:48,height:48}),e("path",{d:"M24,2 C36.1502645,2 46,11.8497355 46,24 C46,36.1502645 36.1502645,46 24,46 C11.8497355,46 2,36.1502645 2,24 C2,11.8497355 11.8497355,2 24,2 Z M24,5 C13.5065898,5 5,13.5065898 5,24 C5,34.4934102 13.5065898,43 24,43 C34.4934102,43 43,34.4934102 43,24 C43,13.5065898 34.4934102,5 24,5 Z M33.5,22.9 L33.5,25.1 C33.5,25.3209139 33.3209139,25.5 33.1,25.5 L14.9,25.5 C14.6790861,25.5 14.5,25.3209139 14.5,25.1 L14.5,22.9 C14.5,22.6790861 14.6790861,22.5 14.9,22.5 L33.1,22.5 C33.3209139,22.5 33.5,22.6790861 33.5,22.9 Z",id:"MinusCircleOutline-形状",fill:"currentColor",fillRule:"nonzero"})]})})})}const b=r.div`
     margin:20px 10px;
`,A=r.h3`
    font-size:24px;
    padding: 15px 0;
    text-align:center;
    margin-top: 8px;
`,F=r.div`
    svg{
        path{
            fill: #4A4A4A!important;
        }
    }
`,z=()=>{y.useForm();const n=f(),i=m();g.useMemo(()=>v(i.map(t=>t.host))||[],[i]);const u=t=>{C(),n(-1)},h=async t=>{console.log(t);const o=await x(t.host);console.log(o)};return e(a,{children:l(a.Body,{children:[e(c,{left:e(F,{onClick:()=>{n(-1)},children:c.Back})}),l(b,{children:[e(A,{children:"Dapp connections"}),i.length>0?l(s,{style:{"--border-bottom":"0"},children:[i.map((t,o)=>e(s.Item,{extra:e(d,{fill:"none",onClick:()=>{h(t)},children:e(w,{})}),children:t.host},o)),e(s.Item,{children:e(d,{block:!0,type:"submit",color:"primary",size:"large",onClick:u,children:"Reset all dapp connections"})})]}):e("div",{style:{margin:"30px",fontSize:"12",textAlign:"center"},children:"you haven't connected to any dapp yet."})]})]})})};export{z as default};
//# sourceMappingURL=index-25aa3186.js.map
