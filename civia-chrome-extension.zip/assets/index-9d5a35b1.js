import{X as c,o as n,n as o,p as t}from"./index.html-a1016547.js";import{u}from"./useDisplayTokenAmountAndCurrencyValue-c18faa62.js";import"./index-23cb1aae.js";const p=c.div`
    display: flex;
`,x=({transaction:i})=>{const{action:s,amount:d,tokenAddress:a}=i,{displayAmount:e,displayValue:r}=u({amount:d,tokenAddress:a});if(!e)return null;const l=s==="SEND"?o(t,{children:"−"}):s==="RECEIVE"?o(t,{children:"+"}):null;return n(p,{children:[n("div",{children:[l,e]}),r&&n("div",{children:[l,r]})]})};export{x as TransferAccessory};
//# sourceMappingURL=index-9d5a35b1.js.map
