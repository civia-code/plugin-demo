import{a_ as p,aV as k,bE as N,bF as m}from"./index-23cb1aae.js";import{X as r,bv as u,a4 as w,bx as x,n as t,W as n,o as d,j as c,q as i}from"./index.html-a1016547.js";const l=p(e=>({selectedNetwork:void 0,setSelectedNetwork:s=>e({selectedNetwork:s})})),g=()=>[l(e=>e.selectedNetwork),l(e=>e.setSelectedNetwork)],h=r.div`
     margin:0px 10px;
`,S=r.h3`
    font-size:24px;
    padding: 15px 0;
    text-align:center;
    margin-top: 8px;
`,v=r.div`
    svg{
        path{
            fill: #4A4A4A!important;
        }
    }
`,B=()=>{const e=u(),s=w();g();const a=x();return k.useMemo(()=>N(a,m),[a]),t(n,{children:d(n.Body,{children:[t(c,{left:t(v,{onClick:()=>{s(-1)},children:c.Back})}),d(h,{children:[t(S,{children:"Networks"}),t(i,{children:e.map(o=>t(i.Item,{description:o.id,children:o.name},o.id))})]})]})})};export{B as default};
//# sourceMappingURL=index-1e430cb1.js.map
