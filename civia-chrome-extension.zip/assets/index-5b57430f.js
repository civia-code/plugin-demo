import{a_ as E,bC as p,H as v,_ as w,a$ as h,aV as u}from"./index-23cb1aae.js";import{bp as R,X as o,a4 as x,a5 as P,n as a,W as f,o as d,j as m,ad as B,a3 as c,a0 as b,bi as A,as as y,aL as C}from"./index.html-a1016547.js";import{T as _}from"./index-5f39c8dc.js";E(()=>({}));const I=e=>{const s=p.en.split(e.trim());if(s.length!==12||!s.every(t=>p.en.getWordIndex(t)>=0))return!1;try{v.fromMnemonic(e)}catch{return!1}return!0},k=e=>e.length>5,D=e=>Boolean(e.seedPhrase&&e.password&&I(e.seedPhrase)&&k(e.password)),F=async(e,s)=>{const t=JSON.stringify({seedPhrase:e,newPassword:s}),r=await R(t);if(w({type:"RECOVER_SEEDPHRASE",data:{secure:!0,body:r}}),!await Promise.race([h("RECOVER_SEEDPHRASE_RES").then(()=>!0),h("RECOVER_SEEDPHRASE_REJ").then(()=>!1).catch(()=>!1)]))throw Error("Invalid Seed Phrase")},H=()=>{w({type:"DOWNLOAD_BACKUP_FILE"})};try{window.downloadBackup=H}catch{}const O=o.div`
    padding: 10px;
`,N=o.h3`
    font-size:24px;
    padding: 15px 0;
    text-align:center;
    margin-top: 8px;
`,W=o.div`
    svg{
        path{
            fill: #4A4A4A!important;
        }
    }
`,L=o.div`
    color:#999;
    padding:0 10px 10px;
`,T=()=>{const e=x(),s=P(),[t,r]=u.useState(!1);console.log(s),u.useEffect(()=>{s&&s.address&&e("/account/home")},[s]);const i=async g=>{const{seedPhrase:l,password:n}=g;if(!/^\w{5,30}$/.test(n))return y.show({icon:"fail",content:"Password is tool simple!"});D({seedPhrase:l,password:n})?(r(!0),await F(l,n).then(async()=>{r(!1),await C()}).catch(S=>{r(!1),y.show({content:S.toString()})})):console.log("invalid seed")};return a(f,{loading:t,children:d(f.Body,{children:[a(m,{left:a(W,{onClick:()=>{e(-1)},children:m.Back})}),a(N,{children:"Restore accounts"}),a(O,{children:d(B,{children:[a(L,{children:"Enter each of the 12 words from your recovery phrase separated by a space"}),d(c,{onFinish:i,footer:a(b,{block:!0,type:"submit",color:"primary",size:"large",style:{borderRadius:"20px"},children:"Submit"}),children:[a(c.Item,{name:"seedPhrase",children:a(_,{placeholder:"seed",rows:4,autoSize:!0})}),a(c.Item,{name:"password",children:a(A,{placeholder:"password",type:"password",maxLength:30})})]})]})})]})})};export{T as default};
//# sourceMappingURL=index-5b57430f.js.map
