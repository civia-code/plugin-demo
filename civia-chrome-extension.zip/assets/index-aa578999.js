import{X as s,q as e,a4 as m,a5 as p,o,p as u,n as t,ad as a,h,b8 as b,b7 as y,a0 as x}from"./index.html-a1016547.js";import"./index-23cb1aae.js";import{PendingTransactionsCom as g,AccountActivity as k}from"./index-720ec510.js";import"./transformTransaction-662c19cf.js";import"./aspect.service-1342d8b4.js";import"./is-b46cff69.js";import"./useDisplayTokenAmountAndCurrencyValue-c18faa62.js";const i=s(e.Item)`
    text-align: center;
`,S=s(e)`
    --border-inner: 0;
    --border-bottom: 0;
    --border-top: 0;
`,B=({tokenAddress:c,currentToken:r,balanceStr:f,imageUrl:d})=>{const l=m(),n=p();return o(u,{children:[t(a,{children:o(S,{children:[t(i,{children:t(h,{...b(r),url:d,size:64})}),t(i,{children:y(r)}),t(e.Item,{children:t(x,{block:!0,color:"primary",onClick:()=>{l(`/tokens/${c}`,{state:{type:"send"}})},style:{borderRadius:"20px",padding:"10px 12px"},children:"Send"})})]})}),n?t(a,{children:o(e,{mode:"card",children:[t(g,{account:n}),t(k,{account:n})]})}):null]})};export{B as default};
//# sourceMappingURL=index-aa578999.js.map
