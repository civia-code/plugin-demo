import{b0 as f,b5 as n}from"./index-23cb1aae.js";import{a}from"./aspect.service-1342d8b4.js";const i=(s,e)=>{const{data:t=[],...r}=f(s&&[n(s),"nfts"],()=>s&&a(s),{refreshInterval:6e4,suspense:!0,...e});return{nfts:t,...r}};export{i as u};
//# sourceMappingURL=useNfts-8eacf436.js.map
