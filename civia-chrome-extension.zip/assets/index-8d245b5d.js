import{aV as r,bi as k,B as C}from"./index-23cb1aae.js";import{X as o,q as u,a5 as S,a4 as I,aB as A,aG as N,o as t,p as B,n as e,aC as w,bh as R,bi as T,am as j,f as F,a0 as p,bj as M,bk as P}from"./index.html-a1016547.js";import{C as L}from"./CloseCircleOutline-d09d2799.js";const m=o(u.Item)`
    border: 1px solid #eee;
    margin: 12px 20px;
    padding: 0 10px 0 20px;
    border-radius: 3px;
`,h=o.div`
    position:relative;
    display:flex;
    align-items: center;
    >div{
        vertical-align: middle;
       

        &:nth-of-type(1){
            width:100%;
        }
        &:nth-of-type(2){
            
        }
    }
`,U=o.div`
    display: flex;

    Button{
        border-radius: 25px;
        min-width:25px;
        height:100%;
        color:#fff;
        padding:0 5px;
        margin:0 5px;
    }
`,E=({contractAddress:g,nftDetail:x})=>{const v=S(),f=I(),{sendTransaction:y}=P(),[s,i]=r.useState(),[a,c]=r.useState(),{accountNames:l}=A(),n=r.useMemo(()=>a?"name"in a?a.name:N(a,l):void 0,[l,a]),b=async()=>{const d=await y({to:g,method:"transferFrom",calldata:{from_:v.address,to:s||a?.address,tokenId:M(C.from(x.token_id))}});console.log(d),f("/dapp")};return t(B,{children:[a&&n?e(m,{prefix:e(w,{src:R({accountName:n,accountAddress:a.address,networkId:a.networkId,backgroundColor:a.hidden?"333332":void 0}),style:{borderRadius:12},fit:"cover",width:24,height:24}),children:t(h,{children:[t("div",{children:[e("div",{children:n}),e("div",{style:{fontSize:12},children:k(a.address)})]}),e("div",{onClick:()=>{c(void 0)},children:e(L,{})})]})}):e(m,{children:t(h,{children:[e("div",{children:e(T,{value:s,onChange:d=>{i(d)},placeholder:"Recipient's address"})}),e("div",{children:e(U,{children:e("div",{children:e(j,{trigger:"click",content:e(F,{onChange:d=>{i(void 0),c(d)}}),children:e(p,{color:"primary",children:"@"})})})})})]})}),e(u.Item,{children:e(p,{color:"primary",onClick:b,block:!0,disabled:!(a||s),style:{borderRadius:"20px",padding:"10px 12px"},children:"Next"})})]})};export{E as default};
//# sourceMappingURL=index-8d245b5d.js.map
