import{af as u,ae as m,n as e,ai as h,bB as y,X as n,a4 as g,W as c,o as l,j as d,q as t,aU as v,bC as x,ar as P,as as b,a0 as S}from"./index.html-a1016547.js";import{aV as i}from"./index-23cb1aae.js";const p="adm-tag",w={default:"#666666",primary:"var(--adm-color-primary, #1677ff)",success:"var(--adm-color-success, #00b578)",warning:"var(--adm-color-warning, #ff8f1f)",danger:"var(--adm-color-danger, #ff3141)"},C={color:"default",fill:"solid",round:!1},B=a=>{var o;const r=u(C,a),s=(o=w[r.color])!==null&&o!==void 0?o:r.color,f={"--border-color":s,"--text-color":r.fill==="outline"?s:"#ffffff","--background-color":r.fill==="outline"?"transparent":s};return m(r,e("span",{style:f,onClick:r.onClick,className:h(p,{[`${p}-round`]:r.round}),children:r.children}))},k=B,N=()=>{const[a,o]=i.useState();return i.useEffect(()=>{(async()=>{const r=await y();o(r)})()},[]),a},j=n.div`
     margin:20px 10px;
`,I=n.h3`
    font-size:24px;
    padding: 15px 0;
    text-align:center;
    margin-top: 8px;
`,R=n.div`
    svg{
        path{
            fill: #4A4A4A!important;
        }
    }
`,W=n(t)`
    --border-bottom: 0;
`,T=()=>{const a=g(),o=N();return e(c,{children:l(c.Body,{children:[e(d,{left:e(R,{onClick:()=>{a(-1)},children:d.Back})}),e(I,{children:"Recovery phrase"}),e(j,{children:l(W,{mode:"card",children:[e(t.Item,{children:"Write these words down on paper. It is unsafe to save them on your computer."}),e(t.Item,{children:e(v,{wrap:!0,justify:"center",children:o?o.split(/\s+/g).map((r,s)=>e(k,{round:!0,children:r},s)):e(x,{color:"primary"})})}),e(t.Item,{children:e(P,{onCopy:()=>b.show({content:"copyed"}),text:o,children:e(S,{block:!0,style:{borderRadius:"20px"},color:"primary",size:"large",children:"Copy"})})})]})})]})})};export{T as default};
//# sourceMappingURL=index-fe45cb39.js.map
