import{aV as x}from"./index-23cb1aae.js";import{X as s,Y as g,Z as y,o,p as l,n as t,_ as a,$ as C,a0 as b,a1 as v,a2 as w}from"./index.html-a1016547.js";const d=s(b)`
    border-radius: 20px;
    padding: 10px 12px;
`,I=s.div`
    padding-bottom: 10px;
`,A=s(v)`
    .adm-center-popup-wrap {
        max-width: 400px!important;
    }
`,B=({account:n})=>{const[u,r]=x.useState(0),{accountInfoData:k={},accountInfoValidating:p,mutate:S}=g(n,n.address),i=y().filter(e=>{const{transactions:[{calldata:f,entrypoint:c}]}=e.payload;return c==="create_sbt"||c==="register"?f.includes(n.address):!1}),m=()=>{r(-1)},h=async()=>{r(1);const e=await w(n.address);console.log(e)};return p?null:o(l,{children:[u===0?t(l,{children:t(A,{visible:!0,content:o("div",{children:[t(I,{children:"You have not created id and other information. If you want to use all functions, please click the Continue button below to complete the overall process."}),t("div",{children:o(a,{columns:2,gap:32,children:[t(a.Item,{children:t(d,{onClick:m,block:!0,style:{width:"100px",margin:"auto"},children:"Cancel"})}),t(a.Item,{children:t(d,{color:"primary",onClick:h,block:!0,style:{width:"100px",margin:"auto"},children:"Continue"})})]})})]})})}):null,i.length>0?t(C,{actions:i}):null]})};export{B as AccountCompleteGuideCom};
//# sourceMappingURL=index-915f90eb.js.map
