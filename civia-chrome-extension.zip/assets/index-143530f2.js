import{aV as i,r as g,aC as v}from"./index-23cb1aae.js";import{X as s,_ as u,a4 as b,a5 as w,aN as A,aO as I,n as e,W as p,o as L,j as h,m as N,L as x,aH as k,an as B}from"./index.html-a1016547.js";const{decodeShortString:C}=v,E=s.h3`
    font-size:24px;
    padding: 15px 0;
    text-align:center;
    margin-top: 8px;
`,F=s.div`
    svg{
        path{
            fill: #4A4A4A!important;
        }
    }
`;s.div`
    padding: 10px 13px;
    
    .adm-search-bar-input-box{
        --border-radius: 20px;
        flex-direction: row-reverse;
        padding-right: var(--padding-left);
    }
`;s(u)`
    margin: 22px;
`;s(B)`
    margin:0 auto;
    border-radius:28px;
    width:56px;
    height:56px;
`;s(u.Item)`
    >div{
        border-radius: 10px;
        /* height:100px; */
        background:#F2F3F5;
        text-align:center;
        padding: 6px 0;
        ${({hasSbt:r})=>r?"":"filter: grayscale(100%);"}
    }
`;const j=s.div`
    padding: 32px 0;
    text-align: center;
`,R=()=>{const r=b(),[f,G]=i.useState(!1);i.useState();const d=w(),l=`${d?.address},buddy`,[a,m]=i.useState(JSON.parse(window.localStorage.getItem(l))||[]);console.log("searchedRes ---",a),A();const[S,y]=i.useState(!0);return i.useEffect(()=>{const c=window.localStorage.getItem("isfresh");console.log("isfresh -----",c),c==="1"?console.log("从别人主页回来不刷新页面"):(console.log("从其他页面过来要判断刷新"),d&&a&&a.length<50&&(console.log("不到50个继续加载"),I(d?.address,1,100).then(t=>{if(t&&t?.length){const n=[];for(let o=0;o<t[0].length;o++)t[0][o].length>10&&n.push({address:g.toHex(t[0][o]),accountId:g.hexToDecimalString(t[1][o]),nickname:C(t[2][o])});console.log("list -----",n),window.localStorage.setItem(l,JSON.stringify(n)),m(n),y(!1)}})))},[]),e(p,{children:L(p.Body,{children:[e(h,{left:e(F,{onClick:()=>{r(-1)},children:h.Back})}),e(E,{children:"Follow friends"}),a&&a.length?e(N,{gridType:"flex",gridNum:3,list:a}):S?e(x,{visible:!0}):e(j,{children:e(k,{})}),e(x,{visible:f,mask:!1})]})})};export{R as default};
//# sourceMappingURL=index-143530f2.js.map
