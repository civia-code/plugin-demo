import{X as a,a4 as s,a5 as o,o as d,n as t,al as c,q as e}from"./index.html-a1016547.js";import"./index-23cb1aae.js";const l=a.div`
    min-height:320px;
    margin: 10px 0;
`,g=a(e)`
    margin: 0 20px;
`,h=a.h3`
    font-size:24px;
    padding: 15px 0;
    text-align:center;
    margin-top: 8px;
`,u=()=>{const n=s(),r=o(),i=r.networkId==="mainnet-alpha"?"https://starkgate.starknet.io":r.networkId==="goerli-alpha"&&"https://goerli.starkgate.starknet.io";return d("div",{children:[t(c,{back:"back",onBack:()=>{n(-1)}}),t(h,{children:"Bridge your assets"}),t(l,{children:t(g,{children:i?t(e.Item,{description:"Bridge trustlessly from Ethereum",onClick:()=>{chrome.tabs.create({url:i})},children:"StarkGate"}):t(e.Item,{description:"Not available for this network",disabled:!0,children:"Bridge from Ethereum"})})})]})};export{u as default};
//# sourceMappingURL=index-c6dd0eb7.js.map
