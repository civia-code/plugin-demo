import{X as t,a4 as n,n as e,W as o,o as s,j as i,q as r,a0 as l,bA as d,aE as c}from"./index.html-a1016547.js";import"./index-23cb1aae.js";const p=t.div`
     margin:20px 10px;
`,h=t.h3`
    font-size:24px;
    padding: 15px 0;
    text-align:center;
    margin-top: 8px;
`,y=t.div`
    svg{
        path{
            fill: #4A4A4A!important;
        }
    }
`,m=t(r)`
    --border-bottom: 0;
`,x=()=>{const a=n();return e(o,{children:s(o.Body,{children:[e(i,{left:e(y,{onClick:()=>{a(-1)},children:i.Back})}),e(h,{children:"Reset wallet"}),e(p,{children:s(m,{mode:"card",children:[e(r.Item,{children:"If you reset your wallet, the only way to recover it is with your 12-word seed phrase. Make sure to back it up from the Civia settings and save it somewhere securely before resetting the extension"}),e(r.Item,{children:e(l,{block:!0,onClick:()=>{d(),localStorage.clear(),c.setState({}),a("/onboarding/password")},color:"primary",size:"large",style:{borderRadius:"20px"},children:"reset"})})]})})]})})};export{x as default};
//# sourceMappingURL=index-339c4077.js.map
