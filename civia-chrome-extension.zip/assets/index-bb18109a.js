import{aV as g,b5 as k}from"./index-23cb1aae.js";import{X as a,a4 as S,a7 as f,bg as y,a5 as h,b6 as x,n as t,W as i,o as T,j as c}from"./index.html-a1016547.js";import b from"./index-aa578999.js";import A from"./index-a23db5bc.js";import"./index-720ec510.js";import"./transformTransaction-662c19cf.js";import"./aspect.service-1342d8b4.js";import"./is-b46cff69.js";import"./useDisplayTokenAmountAndCurrencyValue-c18faa62.js";import"./CloseCircleOutline-d09d2799.js";const v=a.div`
    min-height:320px;
    margin: 10px 0;
`,B=a.h3`
    font-size:24px;
    padding: 15px 0;
    text-align:center;
    margin-top: 8px;
`,C=a.div`
    svg{
        path{
            fill: #4A4A4A!important;
        }
    }
`,H=()=>{const l=S(),{id:n}=f(),m=y(),o=h(),{tokenDetails:d}=x(o),[r,W]=g.useState(()=>d.find(({address:u})=>u===n)),{type:s}=m.state||{},p=o&&k(o),e=JSON.parse(window.localStorage.getItem(`@"${p}","myToken"`));return t(i,{children:T(i.Body,{children:[t(c,{left:t(C,{onClick:()=>{l(-1)},children:c.Back})}),t(B,{children:(s==="detail"?"":"Send ")+e.symbol}),t(v,{children:s==="detail"?t(b,{tokenAddress:n,currentToken:r,imageUrl:e.image,balanceStr:e.balanceStr}):t(A,{tokenAddress:n,currentToken:r,imageUrl:e.image,balanceStr:e.balanceStr})})]})})};export{H as default};
//# sourceMappingURL=index-bb18109a.js.map
